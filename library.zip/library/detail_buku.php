<?php
session_start();
require_once 'config/koneksi.php';

// 1. Ambil ID Buku dari URL
$id_buku = $_GET['id'] ?? '';

if (empty($id_buku)) {
    header("Location: katalog.php");
    exit;
}

try {
    // 2. Ambil data utama buku
    $stmt = $pdo->prepare("SELECT * FROM buku WHERE id_buku = ?");
    $stmt->execute([$id_buku]);
    $buku = $stmt->fetch(PDO::FETCH_ASSOC);

    // --- LOGIKA CEK STATUS PEMINJAMAN ---
$teks_tombol = "Ajukan Pinjaman";
$link_tombol = "anggota/pinjam.php?id=" . $id_buku;
$warna_tombol = "#7B2FBE"; // Default Ungu
$bisa_diklik = true;

// Cek apakah user sudah login sebagai anggota
if (isset($_SESSION['id_user']) && $_SESSION['role'] === 'anggota') {
    $id_anggota = $_SESSION['id_user'];
    
    // Cek apakah ada transaksi aktif/menunggu untuk buku ini
    $stmt_cek = $pdo->prepare("SELECT status_akses, tenggat_kembali FROM transaksi WHERE id_buku = ? AND id_anggota = ? ORDER BY id_transaksi DESC LIMIT 1");
    $stmt_cek->execute([$id_buku, $id_anggota]);
    $cek_transaksi = $stmt_cek->fetch();

    if ($cek_transaksi) {
        $waktu_sekarang = new DateTime();
        $batas_waktu = new DateTime($cek_transaksi['tenggat_kembali']);

        if ($cek_transaksi['status_akses'] == 'Menunggu Konfirmasi') {
            $teks_tombol = "Menunggu Konfirmasi Admin";
            $link_tombol = "#";
            $warna_tombol = "#F59E0B";
            $bisa_diklik = false;
        } elseif ($cek_transaksi['status_akses'] == 'Aktif' && $waktu_sekarang <= $batas_waktu) {
            $teks_tombol = "Baca Buku Sekarang";
            $link_tombol = "uploads/isi-buku/" . $buku['isi_buku'];
            $warna_tombol = "#10B981"; // Hijau
            $bisa_diklik = true;
        }
    }
}
// ------------------------------------

    // Jika user iseng memasukkan ID yang tidak ada
    if (!$buku) {
        echo "<script>alert('Buku tidak ditemukan!'); window.location='katalog.php';</script>";
        exit;
    }

    // 3. Ambil daftar kategori buku menggunakan relasi JOIN
    $query_kategori = "
        SELECT k.nama_kategori 
        FROM kategori k 
        JOIN kategori_buku kb ON k.id_kategori = kb.id_kategori 
        WHERE kb.id_buku = ?
    ";
    $stmt_kategori = $pdo->prepare($query_kategori);
    $stmt_kategori->execute([$id_buku]);
    
    // fetchAll(PDO::FETCH_COLUMN) akan mengambil namanya saja menjadi array seperti ['Fiksi', 'Misteri']
    $daftar_kategori = $stmt_kategori->fetchAll(PDO::FETCH_COLUMN); 

} catch(PDOException $e) {
    die("Error Database: " . $e->getMessage());
}

// Persiapkan data role
$role = $_SESSION['role'] ?? '';
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($buku['judul']); ?> - Herta's Library</title>
    <link rel="stylesheet" href="libraries/css/all.min.css">
    <link rel="stylesheet" href="assets/css/navbar.css">
    <link rel="stylesheet" href="assets/css/detail_buku.css">
</head>
<body>

    <?php 
        $base_path = ''; // Karena file ada di root
        $show_dashboard_btn = true; // Munculkan tombol ke dashboard/beranda
        include 'includes/navbar.php'; 
    ?>

    <div class="detail-container">
        
        <div class="cover-section">
            <img src="uploads/cover/<?php echo htmlspecialchars($buku['cover']); ?>" alt="Cover Buku" class="cover-gambar">
        </div>

        <div class="info-section">
            <a href="katalog.php" style="display: inline-block; margin-bottom: 20px; color: #8A6BAE; text-decoration: none; font-weight: bold; font-size: 14px; transition: 0.2s;" onmouseover="this.style.color='#5B3F7A'" onmouseout="this.style.color='#8A6BAE'">
                <i class="fa-solid fa-arrow-left"></i> Kembali ke Katalog
            </a>
            <h1 class="judul-buku"><?php echo htmlspecialchars($buku['judul']); ?></h1>
            <div class="penulis-buku"><?php echo htmlspecialchars($buku['penulis']); ?></div>

            <div class="kategori-tags">
                <?php if (!empty($daftar_kategori)): ?>
                    <?php foreach ($daftar_kategori as $kat): ?>
                        <span class="tag"><?php echo htmlspecialchars($kat); ?></span>
                    <?php endforeach; ?>
                <?php else: ?>
                    <span class="tag" style="background: #eee; color: #888;">Tanpa Kategori</span>
                <?php endif; ?>
            </div>

            <div class="metadata-grid">
                <div class="meta-item">
                    <span>Penerbit</span>
                    <strong><?php echo htmlspecialchars($buku['penerbit']); ?></strong>
                </div>
                <div class="meta-item">
                    <span>Tahun Terbit</span>
                    <strong><?php echo htmlspecialchars($buku['tahun_terbit']); ?></strong>
                </div>
                <div class="meta-item">
                    <span>Halaman</span>
                    <strong><?php echo htmlspecialchars($buku['jumlah_halaman']); ?> halaman</strong>
                </div>
            </div>

            <h3 style="color: #1A0A2E; margin-bottom: 10px;">Sinopsis</h3>
            <div class="sinopsis-container" id="sinopsisContainer">
                <div class="sinopsis-preview" id="sinopsisPreview">
                    <?php echo nl2br(htmlspecialchars($buku['blurb'])); ?>
                </div>
                <button class="btn-baca-selengkapnya" id="btnSelengkapnya" onclick="bukaModalSinopsis()">Baca selengkapnya...</button>
            </div>

            <div style="display: flex; gap: 10px; border-top: 1px solid #eee; padding-top: 20px;">
                
                <?php if ($role === ''): // GUEST ?>
                    <a href="auth/login.php" class="btn btn-guest">
                        <i class="fa-solid fa-lock"></i> Login untuk Meminjam
                    </a>

                <?php elseif ($role === 'anggota'): // ANGGOTA ?>
                    <?php if ($bisa_diklik): ?>
        <a href="<?php echo $link_tombol; ?>" style="background-color: <?php echo $warna_tombol; ?>; color: white; padding: 12px 20px; border-radius: 6px; text-decoration: none; font-weight: bold; display: inline-block; text-align: center; transition: 0.3s;" <?php echo ($teks_tombol == 'Baca Buku Sekarang') ? 'target="_blank"' : ''; ?>>
            <?php echo $teks_tombol; ?>
        </a>
    <?php else: ?>
        <span style="background-color: <?php echo $warna_tombol; ?>; color: white; padding: 12px 20px; border-radius: 6px; font-weight: bold; display: inline-block; text-align: center; cursor: not-allowed;">
            <i class="fa-solid fa-clock"></i> <?php echo $teks_tombol; ?>
        </span>
    <?php endif; ?>

                <?php elseif ($role === 'admin'): // ADMIN ?>
                    <a href="uploads/isi-buku/<?php echo htmlspecialchars($buku['isi_buku']); ?>" target="_blank" class="btn btn-admin">
                        <i class="fa-solid fa-book-open"></i> Baca PDF (QC)
                    </a>
                    <a href="admin/edit_buku.php?id=<?php echo $buku['id_buku']; ?>" class="btn btn-edit">
                        <i class="fa-solid fa-pen"></i> Edit Buku
                    </a>

                <?php elseif ($role === 'petugas'): // PETUGAS ?>
                    <a href="uploads/isi-buku/<?php echo htmlspecialchars($buku['file_buku']); ?>" target="_blank" class="btn btn-admin">
                        <i class="fa-solid fa-book-open"></i> Baca PDF
                    </a>
                <?php endif; ?>

            </div>

        </div>
    </div>
    <div id="modalSinopsis" class="modal-overlay" onclick="tutupModalLuar(event)">
        <div class="modal-content-sinopsis">
            <button onclick="tutupModalSinopsis()" style="position: absolute; top: 15px; right: 20px; font-size: 24px; cursor: pointer; border: none; background: none; color: #8A6BAE;">&times;</button>
                <h3 style="color: #1A0A2E; border-bottom: 1px solid #EDE9FE; padding-bottom: 10px; margin-top: 0;">Sinopsis Lengkap</h3>
                <div style="color: #4b5563; line-height: 1.7; text-align: justify; margin-top: 15px;">
                    <?php echo nl2br(htmlspecialchars($buku['blurb'])); ?>
                </div>
        </div>
    </div>
    <script>
        // Logika untuk mengecek apakah teks kepanjangan saat halaman dimuat
        document.addEventListener("DOMContentLoaded", function() {
            var preview = document.getElementById("sinopsisPreview");
            var btn = document.getElementById("btnSelengkapnya");
            
            // Jika tinggi konten asli (scrollHeight) lebih besar dari kotak yang disediakan (clientHeight 120px)
            if (preview.scrollHeight > preview.clientHeight) {
                btn.style.display = "inline-block"; // Munculkan tombol
                preview.classList.add("faded"); // Munculkan efek gradasi memudar
            }
        });

        // Fungsi mengendalikan Modal
        function bukaModalSinopsis() {
            document.getElementById("modalSinopsis").style.display = "flex";
        }

        function tutupModalSinopsis() {
            document.getElementById("modalSinopsis").style.display = "none";
        }

        // Tutup modal jika user mengklik area abu-abu di luar kotak putih
        function tutupModalLuar(event) {
            if (event.target === document.getElementById("modalSinopsis")) {
                tutupModalSinopsis();
            }
        }
    </script>
</body>
</html>