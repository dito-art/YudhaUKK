<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Pastikan yang masuk adalah anggota
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'anggota') {
    header("Location: ../auth/login.php");
    exit;
}

$id_anggota = $_SESSION['id_user'];
$pesan_profil = '';
$pesan_password = '';

// --- LOGIKA 1: PROSES UPDATE NOMOR TELEPON ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_profil'])) {
    $no_telp_baru = trim($_POST['no_telp']);
    
    if (!empty($no_telp_baru)) {
        try {
            $stmt = $pdo->prepare("UPDATE anggota SET no_telp = ? WHERE id_anggota = ?");
            $stmt->execute([$no_telp_baru, $id_anggota]);
            $pesan_profil = "<div class='alert alert-success' style='margin-bottom: 15px;'>Nomor telepon berhasil diperbarui!</div>";
        } catch (PDOException $e) {
            $pesan_profil = "<div class='alert' style='background:#ffebee; color:#c62828; padding:10px; border-radius:4px; margin-bottom:15px;'>Gagal: " . $e->getMessage() . "</div>";
        }
    }
}

// --- LOGIKA 2: PROSES UBAH PASSWORD ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ubah_password'])) {
    $pass_lama = $_POST['password_lama'];
    $pass_baru = $_POST['password_baru'];
    $konfirmasi = $_POST['konfirmasi_password'];

    try {
        // Ambil password lama dari database untuk dicocokkan
        $stmt_cek = $pdo->prepare("SELECT password FROM anggota WHERE id_anggota = ?");
        $stmt_cek->execute([$id_anggota]);
        $user = $stmt_cek->fetch();

        // 1. Cek apakah password lama yang diketik sama dengan di database
        if (password_verify($pass_lama, $user['password'])) {
            // 2. Cek apakah password baru dan konfirmasi sama
            if ($pass_baru === $konfirmasi) {
                // 3. Hash password baru dan simpan
                $pass_hash = password_hash($pass_baru, PASSWORD_DEFAULT);
                $stmt_update = $pdo->prepare("UPDATE anggota SET password = ? WHERE id_anggota = ?");
                $stmt_update->execute([$pass_hash, $id_anggota]);
                
                $pesan_password = "<div class='alert alert-success' style='margin-bottom: 15px;'>Password berhasil diubah!</div>";
            } else {
                $pesan_password = "<div class='alert' style='background:#ffebee; color:#c62828; padding:10px; border-radius:4px; margin-bottom:15px;'>Password tidak cocok!</div>";
            }
        } else {
            $pesan_password = "<div class='alert' style='background:#ffebee; color:#c62828; padding:10px; border-radius:4px; margin-bottom:15px;'>Password lama salah!</div>";
        }
    } catch (PDOException $e) {
        $pesan_password = "<div class='alert' style='background:#ffebee; color:#c62828; padding:10px; border-radius:4px; margin-bottom:15px;'>Error: " . $e->getMessage() . "</div>";
    }
}

// --- AMBIL DATA ANGGOTA UNTUK DITAMPILKAN ---
try {
    $stmt_data = $pdo->prepare("SELECT * FROM anggota WHERE id_anggota = ?");
    $stmt_data->execute([$id_anggota]);
    $anggota = $stmt_data->fetch(PDO::FETCH_ASSOC);
} catch (PDOException $e) {
    die("Error Database: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Profil Saya</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
    <link rel="stylesheet" href="../assets/css/profil.css">
</head>
<body style="background: #F8F7FA;">

    <?php 
    $base_path = '../';
    include '../includes/navbar.php'; 
    ?>

    <div class="main-wrapper">
        <?php include '../includes/sidebar.php'; ?>

        <main class="content-area">
            <h2 style="color: #1A0A2E; margin-bottom: 5px;">Pengaturan Profil</h2>
            <p style="color: #8A6BAE; margin-bottom: 20px;">Kelola informasi akun dan kata sandimu di sini.</p>

            <div class="profil-container">
                
                <div class="card-profil">
                    <h3 class="card-title"><i class="fa-solid fa-user" style="color: #7B2FBE;"></i> Informasi Akun</h3>
                    
                    <?php echo $pesan_profil; ?>

                    <form action="" method="POST">
                        <div class="form-group">
                            <label>Nama Lengkap</label>
                            <input type="text" value="<?php echo htmlspecialchars($anggota['nama_lengkap']); ?>" class="input-readonly" readonly>
                        </div>
                        
                        <div style="display: flex; gap: 15px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Username</label>
                                <input type="text" value="<?php echo htmlspecialchars($anggota['username']); ?>" class="input-readonly" readonly>
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>NIS</label>
                                <input type="text" value="<?php echo htmlspecialchars($anggota['nis']); ?>" class="input-readonly" readonly>
                            </div>
                        </div>

                        <div style="display: flex; gap: 15px;">
                            <div class="form-group" style="flex: 1;">
                                <label>Kelas</label>
                                <input type="text" value="<?php echo htmlspecialchars($anggota['kelas']); ?>" class="input-readonly" readonly>
                            </div>
                            <div class="form-group" style="flex: 1;">
                                <label>Jurusan</label>
                                <input type="text" value="<?php echo htmlspecialchars($anggota['jurusan']); ?>" class="input-readonly" readonly>
                            </div>
                        </div>

                        <div class="form-group">
                            <label>Nomor Telepon (Bisa Diubah)</label>
                            <input type="text" name="no_telp" value="<?php echo htmlspecialchars($anggota['no_telp']); ?>" required style="border-color: #7B2FBE;">
                        </div>

                        <button type="submit" name="update_profil" class="btn-submit">Simpan Nomor Telepon</button>
                    </form>
                </div>

                <div class="card-profil" style="border-top: 4px solid #10B981;">
                    <h3 class="card-title"><i class="fa-solid fa-lock" style="color: #10B981;"></i> Ubah Password</h3>
                    
                    <?php echo $pesan_password; ?>

                    <form action="" method="POST">
                        <div class="form-group">
                            <label>Password Lama</label>
                            <input type="password" name="password_lama" placeholder="Masukkan password saat ini" required>
                            <small style="color: #6B7280; font-size: 12px;">Masukkan password '123456' jika akunmu baru saja di-reset oleh Admin.</small>
                        </div>
                        
                        <div class="form-group">
                            <label>Password Baru</label>
                            <input type="password" name="password_baru" placeholder="Buat password baru" required>
                        </div>

                        <div class="form-group">
                            <label>Konfirmasi Password Baru</label>
                            <input type="password" name="konfirmasi_password" placeholder="Ketik ulang password baru" required>
                        </div>

                        <button type="submit" name="ubah_password" class="btn-submit" style="background: #10B981;">Perbarui Password</button>
                    </form>
                </div>

            </div>
        </main>
    </div>

</body>
</html>