<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Pastikan yang mengakses adalah anggota
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'anggota') {
    header("Location: ../auth/login.php");
    exit;
}

$id_anggota = $_SESSION['id_user'];
$id_buku = $_GET['id'] ?? '';
$pesan_error = '';

// 1. Ambil data buku untuk ditampilkan di form
if (empty($id_buku)) {
    header("Location: ../katalog.php");
    exit;
}

try {
    $stmt_paket = $pdo->query("SELECT * FROM paket_sewa ORDER BY durasi_paket ASC");
    $daftar_paket = $stmt_paket->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error mengambil Paket: " . $e->getMessage());
}

try {
    $stmt_buku = $pdo->prepare("SELECT judul, cover FROM buku WHERE id_buku = ?");
    $stmt_buku->execute([$id_buku]);
    $buku = $stmt_buku->fetch(PDO::FETCH_ASSOC);

    if (!$buku) {
        die("Buku tidak ditemukan.");
    }
} catch (PDOException $e) {
    die("Error Database: " . $e->getMessage());
}

// 2. Logika Pemrosesan Form Checkout
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ajukan'])) {
    $id_paket = $_POST['id_paket'];
    $metode_pembayaran = $_POST['metode_pembayaran'];
    
    $stmt_harga = $pdo->prepare("SELECT harga FROM paket_sewa WHERE id_paket = ?");
    $stmt_harga->execute([$id_paket]);
    $total_biaya = $stmt_harga->fetchColumn();

    if (!$total_biaya) {
        $pesan_error = "Paket sewa tidak valid!";
    }

    // Proses Upload Bukti Pembayaran
    $nama_file_bukti = NULL;
    if (isset($_FILES['bukti_pembayaran']) && $_FILES['bukti_pembayaran']['error'] == 0) {
        $ekstensi_diperbolehkan = ['png', 'jpg', 'jpeg'];
        $nama_file = $_FILES['bukti_pembayaran']['name'];
        $x = explode('.', $nama_file);
        $ekstensi = strtolower(end($x));
        $ukuran = $_FILES['bukti_pembayaran']['size'];
        $file_tmp = $_FILES['bukti_pembayaran']['tmp_name'];

        if (in_array($ekstensi, $ekstensi_diperbolehkan) === true) {
            if ($ukuran < 2048000) { // Maksimal 2MB
                // Buat nama file unik agar tidak bentrok
                $nama_file_bukti = time() . '_' . $id_anggota . '.' . $ekstensi;
                // Pastikan folder uploads/bukti/ sudah kamu buat sebelumnya!
                move_uploaded_file($file_tmp, '../uploads/bukti/' . $nama_file_bukti);
            } else {
                $pesan_error = "Ukuran file terlalu besar. Maksimal 2MB.";
            }
        } else {
            $pesan_error = "Ekstensi file tidak diperbolehkan. Gunakan JPG atau PNG.";
        }
    }

    // Jika upload aman atau tidak ada error, simpan ke database
    if (empty($pesan_error)) {
        try {
            // Kita tidak mengisi tanggal_pinjam dan tenggat_kembali sekarang. 
            // Kolom itu baru diisi oleh Admin saat melakukan "Konfirmasi / ACC"
            $query_insert = "
                INSERT INTO transaksi 
                (id_anggota, id_buku, id_paket, total_biaya, metode_pembayaran, bukti_pembayaran, status_pembayaran, status_akses) 
                VALUES (:anggota, :buku, :paket, :biaya, :metode, :bukti, 'Menunggu Verifikasi', 'Menunggu Konfirmasi')
            ";
            
            $stmt_insert = $pdo->prepare($query_insert);
            $stmt_insert->execute([
                'anggota' => $id_anggota,
                'buku' => $id_buku,
                'paket' => $id_paket,
                'biaya' => $total_biaya,
                'metode' => $metode_pembayaran,
                'bukti' => $nama_file_bukti
            ]);

            // Redirect ke halaman index anggota dengan pesan sukses
            header("Location: index.php?pesan=pengajuan_sukses");
            exit;

        } catch (PDOException $e) {
            $pesan_error = "Gagal memproses transaksi: " . $e->getMessage();
        }
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Checkout Peminjaman</title>
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
    <link rel="stylesheet" href="../assets/css/pinjam.css">
</head>
<body style="background: #F8F7FA;">

    <div class="checkout-container">
        
        <div class="book-preview">
            <img src="../uploads/cover/<?php echo htmlspecialchars($buku['cover']); ?>" alt="Cover Buku">
            <h3 style="color: #1A0A2E; font-size: 16px;"><?php echo htmlspecialchars($buku['judul']); ?></h3>
        </div>

        <div class="form-section">
            <a href="../detail_buku.php?id=<?php echo $id_buku; ?>" style="color: #8A6BAE; text-decoration: none; font-size: 14px; display: inline-block; margin-bottom: 15px;">&larr; Batal & Kembali</a>
            
            <h2 style="color: #1A0A2E; margin-bottom: 20px; border-bottom: 2px solid #EDE9FE; padding-bottom: 10px;">Form Peminjaman</h2>

            <?php if ($pesan_error): ?>
                <div class="alert alert-error" style="background:#ffebee; color:#c62828; padding: 10px; border-radius: 4px; margin-bottom: 15px;"><?php echo $pesan_error; ?></div>
            <?php endif; ?>

            <form action="" method="POST" enctype="multipart/form-data">
                
                <div class="form-group">
                    <select name="id_paket" required>
                        <option value="">-- Pilih Paket --</option>
                        <?php foreach ($daftar_paket as $paket): ?>
                            <option value="<?php echo $paket['id_paket']; ?>">
                                <?php echo htmlspecialchars($paket['nama_paket']); ?> 
                                (Rp <?php echo number_format($paket['harga'], 0, ',', '.'); ?> / <?php echo $paket['durasi_paket']; ?> Hari)
                            </option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div class="form-group">
                    <label>Metode Pembayaran</label>
                    <select name="metode_pembayaran" required>
                        <option value="">-- Pilih Bank/E-Wallet --</option>
                        <option value="BCA">Transfer BCA (572627 a.n Herta's Library)</option>
                        <option value="Mandiri">Transfer Mandiri (987654321 a.n Herta's Library)</option>
                        <option value="Gopay">Gopay (08123456789 a.n Madam Herta)</option>
                    </select>
                </div>

                <div class="form-group" style="background: #F3E8FF; padding: 15px; border-radius: 6px; border: 1px dashed #C084FC;">
                    <label>Upload Bukti Pembayaran (JPG/PNG)</label>
                    <input type="file" name="bukti_pembayaran" accept="image/png, image/jpeg, image/jpg" required>
                    <small style="color: #6b7280; display: block; margin-top: 5px;">Maksimal ukuran file 2MB.</small>
                </div>

                <button type="submit" name="ajukan" class="btn-submit">Selesaikan Pembayaran & Pinjam</button>
            </form>
        </div>

    </div>

</body>
</html>