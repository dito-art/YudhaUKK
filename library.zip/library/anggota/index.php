<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php'; // Jangan lupa panggil koneksi database

// Satpam Pengecek Login
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'anggota') {
    header("Location: ../auth/login.php");
    exit;
}

$id_anggota = $_SESSION['id_user'];

try {
    // Ambil data buku yang statusnya sedang 'menunggu' konfirmasi atau sedang 'dipinjam'
    // Kita JOIN dengan tabel buku agar bisa menampilkan cover dan judulnya
    $query = "
        SELECT t.*, b.judul, b.cover, b.isi_buku 
        FROM transaksi t
        JOIN buku b ON t.id_buku = b.id_buku
        WHERE t.id_anggota = :id_anggota 
        AND t.status_akses IN ('Menunggu Konfirmasi', 'Aktif')
        ORDER BY t.id_transaksi DESC
    ";
    $stmt = $pdo->prepare($query);
    $stmt->execute(['id_anggota' => $id_anggota]);
    $daftar_pinjaman = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    die("Error Database: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Member</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/indexAnggota.css">
</head>
<body>

    <?php
    $base_path = '../';
    include '../includes/navbar.php'; ?>

    <div class="main-wrapper">
        <?php include '../includes/sidebar.php'; ?>

        <main class="content-area" style="padding: 30px;">
            <h2 style="margin-bottom: 5px; color: #1A0A2E;">Halo, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>!</h2>
            <p style="color: #8A6BAE; margin-bottom: 30px;">Selamat datang di rak buku digitalmu.</p>

            <h3 style="color: #5B3F7A; border-bottom: 2px solid #EDE9FE; padding-bottom: 10px;">Buku yang Sedang Dipinjam</h3>

            <?php if (empty($daftar_pinjaman)): ?>
                <div style=" padding: 30px; text-align: center; border-radius: 8px; margin-top: 50px; color: #8A6BAE;">
                    <i class="fa-solid fa-book-open" style="font-size: 40px; margin-bottom: 15px; color: #D8B4FE;"></i>
                    <p>Kamu belum meminjam buku apapun saat ini.</p>
                    <a href="../katalog.php" style="display: inline-block; margin-top: 15px; background: #7B2FBE; color: white; padding: 10px 20px; text-decoration: none; border-radius: 5px; font-weight: bold;">Jelajahi Katalog</a>
                </div>
            <?php else: ?>
                <div class="grid-pinjaman">
                    <?php foreach ($daftar_pinjaman as $pinjam): ?>
                        <div class="card-pinjaman">
                            <img src="../uploads/cover/<?php echo htmlspecialchars($pinjam['cover']); ?>" alt="Cover" class="cover-buku">
                            
                            <div class="info-pinjaman">
                                <div class="judul-buku"><?php echo htmlspecialchars($pinjam['judul']); ?></div>
                                
                                <?php if ($pinjam['status_akses'] === 'Menunggu Konfirmasi'): ?>
                                    <span class="badge-status status-menunggu"><i class="fa-solid fa-clock"></i> Menunggu Konfirmasi</span>
                                    <div class="waktu-sisa" style="font-weight: normal; font-size: 12px;">Admin sedang memproses permintaanmu.</div>
                                
                                <?php elseif ($pinjam['status_akses'] === 'Aktif'): ?>
                                    <span class="badge-status status-dipinjam"><i class="fa-solid fa-book-reader"></i> Sedang Dipinjam</span>
                                    
                                    <?php
                                        // LOGIKA PENGHITUNG WAKTU SISA
                                        $waktu_sekarang = new DateTime();
                                        $batas_waktu = new DateTime($pinjam['tenggat_kembali']);
                                        
                                        if ($waktu_sekarang > $batas_waktu) {
                                            echo '<div class="waktu-sisa waktu-habis"><i class="fa-solid fa-triangle-exclamation"></i> Waktu Habis!</div>';
                                        } else {
                                            $selisih = $waktu_sekarang->diff($batas_waktu);
                                            // Format output: X Hari Y Jam
                                            echo '<div class="waktu-sisa"><i class="fa-solid fa-hourglass-half"></i> Sisa: ' . $selisih->d . ' Hari ' . $selisih->h . ' Jam</div>';
                                        }
                                    ?>
                                    
                                    <?php if ($waktu_sekarang <= $batas_waktu): ?>
                                        <a href="../uploads/isi-buku/<?php echo htmlspecialchars($pinjam['isi_buku']); ?>" target="_blank" class="btn-baca"><i class="fa-solid fa-book-open"></i> Mulai Membaca</a>                              
                                    <?php endif; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>

        </main>
    </div>
</body>
</html>