<?php
$host = "localhost";
$user = "root";
$pass = "";
$db   = "perpus_digital";

try {
    $pdo = new PDO("mysql:host=$host;dbname=$db", $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //echo "Connection Succes";
} catch (PDOException $e) {
    die("Koneksi gagal: " . $e->getMessage());
}
?>