<?php
// auth_guard.php

// 1. Mulai session (cukup dipanggil sekali di file ini)
session_start();

// 2. Matikan Cache Browser (mencegah BFCache saat tombol back ditekan)
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Cache-Control: post-check=0, pre-check=0", false);
header("Pragma: no-cache");
header("Expires: 0");

// 3. Cek akses login
// Catatan: Sesuaikan path '../auth/login.php' dengan lokasi file login aslimu
if (!isset($_SESSION['role'])) {
    header("Location: ../auth/login.php");
    exit;
}
?>