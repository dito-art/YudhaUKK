<?php
require_once '../config/koneksi.php';
session_start(); 
$pesan_error = $_SESSION['pesan_error'] ?? '';
$pesan_sukses = $_SESSION['pesan_sukses'] ?? '';
unset($_SESSION['pesan_error'], $_SESSION['pesan_sukses']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nis = $_POST['nis'];
    $nama_lengkap = $_POST['nama_lengkap'];
    $username = $_POST['username'];
    $password = $_POST['password'];
    $kelas = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];
    $no_telp = $_POST['no_tlp'];

    $password_hashed = password_hash($password, PASSWORD_DEFAULT);

    try {
        $query = "INSERT INTO anggota (nis, nama_lengkap, username, password, kelas, jurusan, no_telp) 
                  VALUES (?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$nis, $nama_lengkap, $username, $password_hashed, $kelas, $jurusan, $no_telp]);
        $_SESSION['pesan_sukses'] = "Pendaftaran berhasil! Silakan login.";
    } catch(PDOException $e) {
        if ($e->getCode() == 23000) {
            $_SESSION['pesan_error'] = "NIS atau Username sudah terdaftar!";
        } else {
            $_SESSION['pesan_error'] = "Terjadi kesalahan: " . $e->getMessage();
        }
    }
    header("Location: register.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Member</title>
    <link rel="stylesheet" href="../assets/css/register.css">
</head>
<body>

<div class="auth-container">
    <h2>Daftar Member Baru</h2>

    <?php if ($pesan_error): ?>
        <div class="alert alert-error"><?php echo $pesan_error; ?></div>
    <?php endif; ?>
    
    <?php if ($pesan_sukses): ?>
        <div class="alert alert-success"><?php echo $pesan_sukses; ?></div>
    <?php endif; ?>

    <form action="" method="POST">
        <div class="form-group">
            <label>NIS</label>
            <input type="text" name="nis" required>
        </div>
        <div class="form-group">
            <label>Nama Lengkap</label>
            <input type="text" name="nama_lengkap" required>
        </div>
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <div class="form-group">
            <label>Kelas</label>
            <select>
                <option value="" disabled selected>-- Pilih Kelas --</option>
                <option value="10">X</option>
                <option value="11">XI</option>
                <option value="12">XII</option>
            </select>
        </div>
        <div class="form-group">
            <label>Jurusan</label>
            <select name="jurusan" required>
                <option value="" disabled selected>-- Pilih Jurusan --</option>
                <option value="RPL">PPLG</option>
                <option value="MPLB">MPLB</option>
                <option value="PM">PM</option>
                <option value="DKV">DKV</option>
                <option value="AKL">AKL</option>
            </select>
        </div>
        <div class="form-group">
            <label>No Telp</label>
            <input type="number" name="no_tlp" required>
        </div>
        <button type="submit" class="btn-submit">Daftar Sekarang</button>
    </form>

    <div class="text-center">
        Sudah punya akun? <a href="login.php" style="text-decoration: none; color: #7B2FBE;">Login di sini</a><br><br>
        <a href="../index.php" style="text-decoration: none; color: #8A6BAE;">&larr; Kembali ke Beranda</a>
    </div>
</div>

</body>
</html>