<?php
// 1. Mulai session untuk memanggil data session yang sedang aktif
session_start();

// 2. Hancurkan semua data session (Logout)
session_unset();
session_destroy();

header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: 0");

// 3. Arahkan kembali ke halaman landing page utama
header("Location: login.php");
exit;
?>