<?php
require_once '../config/koneksi.php';
session_start(); 

$pesan_error = $_SESSION['pesan_error'] ?? '';
unset($_SESSION['pesan_error']);

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

    try {
        // Cek di tabel anggota
        $stmt_anggota = $pdo->prepare("SELECT * FROM anggota WHERE username = ?");
        $stmt_anggota->execute([$username]);
        $user_anggota = $stmt_anggota->fetch(PDO::FETCH_ASSOC);

        if ($user_anggota) {
            
            // --- LOGIKA BARU: CEK STATUS BLOKIR DI SINI ---
            if (isset($user_anggota['status']) && $user_anggota['status'] === 'Nonaktif') {
                $_SESSION['pesan_error'] = "Akun Anda telah dinonaktifkan. Silakan hubungi admin.";
                header("Location: login.php");
                exit;
            }
            // ----------------------------------------------

            if (password_verify($password, $user_anggota['password'])) {
                $_SESSION['id_user'] = $user_anggota['id_anggota'];
                $_SESSION['nama_lengkap'] = $user_anggota['nama_lengkap'];
                $_SESSION['role'] = 'anggota';
                header("Location: ../anggota/index.php");
                exit;
            } else {
                $_SESSION['pesan_error'] = "Password salah!";
                header("Location: login.php");
                exit;
            }
        } else {
            // Jika tidak ketemu di anggota, cek di tabel operator (Admin/Petugas)
            $stmt_petugas = $pdo->prepare("SELECT * FROM operator WHERE username = ?");
            $stmt_petugas->execute([$username]);
            $user_petugas = $stmt_petugas->fetch(PDO::FETCH_ASSOC);

            if ($user_petugas) {
                if (password_verify($password, $user_petugas['password'])) {
                    $_SESSION['id_user'] = $user_petugas['id'];
                    $_SESSION['nama_lengkap'] = $user_petugas['nama_lengkap'];
                    $_SESSION['role'] = $user_petugas['role'];
                    header("Location: ../admin/index.php");
                    exit;
                } else {
                    $_SESSION['pesan_error'] = "Password salah!";
                    header("Location: login.php");
                    exit;
                }
            } else {
                $_SESSION['pesan_error'] = "Username tidak ditemukan";
                header("Location: login.php");
                exit;
            }
        }
    } catch(PDOException $e) {
        $_SESSION['pesan_error'] = "Terjadi kesalahan sistem. " . $e->getMessage();
        header("Location: login.php");
        exit;
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login</title>
    <link rel="stylesheet" href="../assets/css/register.css">
</head>
<body>

<div class="auth-container">
    <h2>Menu Login</h2>

    <?php if ($pesan_error): ?>
        <div class="alert alert-error"><?php echo $pesan_error; ?></div>
    <?php endif; ?>

    <form action="" method="POST">
        <div class="form-group">
            <label>Username</label>
            <input type="text" name="username" required>
        </div>
        <div class="form-group">
            <label>Password</label>
            <input type="password" name="password" required>
        </div>
        <button type="submit" class="btn-submit">Masuk</button>
    </form>

    <div class="text-center">
        Belum punya akun? <a href="register.php" style="text-decoration: none; color: #7B2FBE;">Daftar Member</a><br><br>
        <a href="../index.php" style="text-decoration: none; color: #8A6BAE;">&larr; Kembali ke Beranda</a>
    </div>
</div>

</body>
</html>