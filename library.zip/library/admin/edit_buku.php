<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Pastikan hanya admin yang bisa akses
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$id_buku = $_GET['id'] ?? '';
$pesan = '';

// 1. AMBIL DATA BUKU LAMA
$stmt = $pdo->prepare("SELECT * FROM buku WHERE id_buku = ?");
$stmt->execute([$id_buku]);
$buku_lama = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$buku_lama) {
    die("Data buku tidak ditemukan.");
}

// 2. AMBIL SEMUA KATEGORI (Untuk ditampilkan di form)
$stmt_kat = $pdo->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");
$daftar_kategori = $stmt_kat->fetchAll(PDO::FETCH_ASSOC);

// 3. AMBIL KATEGORI YANG SAAT INI DIPILIH OLEH BUKU INI
$stmt_kat_buku = $pdo->prepare("SELECT id_kategori FROM kategori_buku WHERE id_buku = ?");
$stmt_kat_buku->execute([$id_buku]);
$kategori_terpilih = $stmt_kat_buku->fetchAll(PDO::FETCH_COLUMN); // Menghasilkan array [1, 3, 5]


// JIKA TOMBOL SIMPAN DITEKAN
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Tangkap semua input teks
    $judul = $_POST['judul'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahun_terbit = $_POST['tahun_terbit'];
    $jumlah_halaman = $_POST['jumlah_halaman'];
    $blurb = $_POST['blurb'];

    // Default pakai nama file lama
    $nama_cover_baru = $buku_lama['cover'];
    $nama_pdf_baru = $buku_lama['isi_buku'];

    // PROSES UPLOAD COVER (Jika ada file baru yang dipilih)
    if (!empty($_FILES['cover']['name'])) {
        // Hapus file lama fisik
        if (!empty($buku_lama['cover']) && file_exists('../uploads/cover/' . $buku_lama['cover'])) {
            unlink('../uploads/cover/' . $buku_lama['cover']);
        }
        
        // Buat nama file unik dan pindahkan
        $ext = pathinfo($_FILES['cover']['name'], PATHINFO_EXTENSION);
        $nama_cover_baru = time() . '_cover.' . $ext;
        move_uploaded_file($_FILES['cover']['tmp_name'], '../uploads/cover/' . $nama_cover_baru);
    }

    // PROSES UPLOAD PDF (Jika ada file baru yang dipilih)
    if (!empty($_FILES['file_buku']['name'])) {
        // Hapus file lama fisik
        if (!empty($buku_lama['file_buku']) && file_exists('../uploads/pdf/' . $buku_lama['file_buku'])) {
            unlink('../uploads/pdf/' . $buku_lama['file_buku']);
        }

        // Buat nama file unik dan pindahkan
        $ext = pathinfo($_FILES['file_buku']['name'], PATHINFO_EXTENSION);
        $nama_pdf_baru = time() . '_buku.' . $ext;
        move_uploaded_file($_FILES['file_buku']['tmp_name'], '../uploads/pdf/' . $nama_pdf_baru);
    }

    // UPDATE DATA UTAMA KE TABEL BUKU
    $query_update = "UPDATE buku SET judul = ?, penulis = ?, penerbit = ?, tahun_terbit = ?, jumlah_halaman = ?, blurb = ?, cover = ?, isi_buku = ? WHERE id_buku = ?";
    $stmt_update = $pdo->prepare($query_update);
    $stmt_update->execute([$judul, $penulis, $penerbit, $tahun_terbit, $jumlah_halaman, $blurb, $nama_cover_baru, $nama_pdf_baru, $id_buku]);

    // UPDATE RELASI KATEGORI
    if (isset($_POST['kategori'])) {
        // Hapus relasi lama
        $stmt_hapus = $pdo->prepare("DELETE FROM kategori_buku WHERE id_buku = ?");
        $stmt_hapus->execute([$id_buku]);

        // Masukkan relasi baru
        $stmt_insert = $pdo->prepare("INSERT INTO kategori_buku (id_buku, id_kategori) VALUES (?, ?)");
        foreach ($_POST['kategori'] as $id_kat) {
            $stmt_insert->execute([$id_buku, $id_kat]);
        }
    }

    // Kembali ke halaman kelola buku
    header("Location: kelola_buku.php?pesan=edit_sukses");
    exit;
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Buku</title>
    <link rel="stylesheet" href="../assets/css/tambah_buku.css">
</head>
<body>

    <div class="form-container">
        <h2>Edit Buku</h2>
        <?php echo $pesan; ?>
        
        <form action="" method="POST" enctype="multipart/form-data">
            
            <div class="form-group"><label>Judul Buku</label><input type="text" name="judul" value="<?php echo htmlspecialchars($buku_lama['judul']); ?>" required></div>
            <div class="form-group"><label>Penulis</label><input type="text" name="penulis" value="<?php echo htmlspecialchars($buku_lama['penulis']); ?>" required></div>
            <div class="form-group"><label>Penerbit</label><input type="text" name="penerbit" value="<?php echo htmlspecialchars($buku_lama['penerbit']); ?>" required></div>
            <div class="form-group"><label>Tahun Terbit</label><input type="number" name="tahun_terbit" value="<?php echo htmlspecialchars($buku_lama['tahun_terbit']); ?>" required></div>
            <div class="form-group"><label>Jumlah Halaman</label><input type="number" name="jumlah_halaman" value="<?php echo htmlspecialchars($buku_lama['jumlah_halaman']); ?>" required></div>
            
            <div class="form-group"><label>Blurb (Sinopsis Singkat)</label><textarea name="blurb" rows="4" required><?php echo htmlspecialchars($buku_lama['blurb']); ?></textarea></div>
            
            <div class="form-group">
                <label>Pilih Kategori Buku</label>
                <div class="kategori-container">
                    <?php foreach ($daftar_kategori as $kat): ?>
                        <label class="kategori-item">
                            <input type="checkbox" name="kategori[]" value="<?php echo $kat['id_kategori']; ?>" 
                                <?php echo in_array($kat['id_kategori'], $kategori_terpilih) ? 'checked' : ''; ?>>
                            <?php echo htmlspecialchars($kat['nama_kategori']); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-group">
                <label>Ganti Cover Buku (Opsional)</label>
                <span style="font-size: 12px; color: #8A6BAE; display: block; margin-bottom: 5px;">*Biarkan kosong jika tidak ingin mengubah cover. (Cover saat ini: <?php echo htmlspecialchars($buku_lama['cover']); ?>)</span>
                <input type="file" name="cover" accept="image/*">
            </div>

            <div class="form-group">
                <label>Ganti File PDF (Opsional)</label>
                <span style="font-size: 12px; color: #8A6BAE; display: block; margin-bottom: 5px;">*Biarkan kosong jika tidak ingin mengubah isi buku. (File saat ini: <?php echo htmlspecialchars($buku_lama['isi_buku']); ?>)</span>
                <input type="file" name="file_buku" accept="application/pdf">
            </div>
            
            <button type="submit" class="btn-submit">Simpan Perubahan</button>
            <a href="kelola_buku.php" style="margin-left: 10px; color: #8A6BAE; text-decoration: none;">Batal</a>
        </form>
    </div>

</body>
</html>