<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Pastikan hanya admin yang bisa melakukan aksi ini
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Tangkap parameter dari URL
$id_anggota = $_GET['id'] ?? '';
$status_baru = $_GET['status'] ?? '';

// Validasi data
if (!empty($id_anggota) && in_array($status_baru, ['aktif', 'nonaktif'])) {
    try {
        $query = "UPDATE anggota SET status = :status WHERE id_anggota = :id";
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            'status' => $status_baru,
            'id' => $id_anggota
        ]);

        // Redirect kembali dengan pesan sukses (opsional: tangkap pesan ini di kelola_anggota.php)
        header("Location: kelola_anggota.php?pesan=status_berubah");
        exit;

    } catch(PDOException $e) {
        die("Error sistem: " . $e->getMessage());
    }
} else {
    // Jika parameter ngawur, kembalikan saja ke halaman kelola
    header("Location: kelola_anggota.php");
    exit;
}
?>