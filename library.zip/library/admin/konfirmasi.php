<?php
// Memanggil file pendukung seperti konfigurasi database, fungsi bantuan, dan perlindungan halaman (login)
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';
require_once '../includes/functions.php';

// Ini berfungsi untuk mengecek hak akses. Kalau usernya belum login atau bukan admin/petugas, dia akan ditendang balik ke halaman index.php
if (!isset($_SESSION['id_user']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'petugas')) {
    header("Location: index.php");
    exit;
}

try {
    // 1. Panggil keyword dan atur pagination (pembagian halaman)
    $keyword = dapatkan_keyword();
    $batas = 5; // Ini berfungsi untuk membatasi jumlah data yang tampil di tabel (cuma 5 baris per halaman)
    $halaman_aktif = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1; // Mendapatkan posisi halaman saat ini
    $awal_data = ($batas * $halaman_aktif) - $batas; // Menghitung index awal data untuk query LIMIT di database

    // 2. Logika Pencarian
    if (!empty($keyword)) {
        // A. COUNT Pencarian: Ini berfungsi untuk menghitung total baris transaksi berdasarkan keyword pencarian (nama atau judul buku)
        $query_count = "
            SELECT COUNT(*) 
            FROM transaksi t
            JOIN anggota a ON t.id_anggota = a.id_anggota
            JOIN buku b ON t.id_buku = b.id_buku
            WHERE a.nama_lengkap LIKE :keyword_nama OR b.judul LIKE :keyword_judul
        ";
        $stmt_count = $pdo->prepare($query_count);
        $stmt_count->execute([
            'keyword_nama' => "%$keyword%",
            'keyword_judul' => "%$keyword%"
        ]);
        $total_data = $stmt_count->fetchColumn();

        // B. SELECT Data Aktual dengan LIMIT: Ini berfungsi untuk menarik data hasil pencarian secara nyata dari database sesuai batas halamannya
        $query = "
            SELECT t.*, a.nama_lengkap, b.judul, p.nama_paket 
            FROM transaksi t
            JOIN anggota a ON t.id_anggota = a.id_anggota
            JOIN buku b ON t.id_buku = b.id_buku
            JOIN paket_sewa p ON t.id_paket = p.id_paket
            WHERE a.nama_lengkap LIKE :keyword_nama OR b.judul LIKE :keyword_judul
            ORDER BY t.id_transaksi DESC 
            LIMIT :awal, :batas
        ";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':keyword_nama', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':keyword_judul', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();

    } else {
        // LOGIKA NORMAL (JIKA TIDAK MENCARI APA-APA)
        
        // A. COUNT Normal: Ini berfungsi untuk menghitung seluruh data transaksi yang ada di database untuk keperluan penomoran halaman
        $stmt_count = $pdo->query("SELECT COUNT(*) FROM transaksi");
        $total_data = $stmt_count->fetchColumn();

        // B. SELECT Normal dengan LIMIT: Ini berfungsi untuk menarik seluruh data transaksi, diurutkan dari yang paling baru
        $query = "
            SELECT t.*, a.nama_lengkap, b.judul, p.nama_paket 
            FROM transaksi t
            JOIN anggota a ON t.id_anggota = a.id_anggota
            JOIN buku b ON t.id_buku = b.id_buku
            JOIN paket_sewa p ON t.id_paket = p.id_paket
            ORDER BY t.id_transaksi DESC 
            LIMIT :awal, :batas
        ";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    }

    // Ini berfungsi untuk menghitung berapa jumlah halaman yang akan dibuat (membulatkan ke atas hasil bagi total data dan batas)
    $total_halaman = ceil($total_data / $batas);
    // Ini berfungsi untuk mengeksekusi dan menyimpan seluruh hasil query ke dalam bentuk Array biar bisa ditampilkan ke HTML nanti
    $daftar_transaksi = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Ini berfungsi sebagai pengaman. Kalau databasenya bermasalah/error, script berhenti dan menampilkan pesan errornya
    die("Error Database: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Transaksi Peminjaman</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
</head>
<body>
    <?php 
    // Ini berfungsi untuk menyiapkan konfigurasi bagian Navbar (menu navigasi atas) sebelum di-include
    $base_path = '../';
    $search_action = 'konfirmasi.php';
    $search_placeholder = 'Cari nama anggota atau judul buku...';
    include '../includes/navbar.php'; 
    ?>
    
    <div class="main-wrapper">
        <?php include '../includes/sidebar.php'; // Ini berfungsi untuk menampilkan menu di sebelah kiri ?>

        <main class="content-area">
            <h2 style="color: #1A0A2E; margin-bottom: 20px;">Kelola Transaksi & Pembayaran</h2>

            <?php 
            // Ini berfungsi untuk menangkap respon URL. Kalau di URL ada ?pesan=sukses, akan muncul alert notifikasi hijau
            if (isset($_GET['pesan']) && $_GET['pesan'] == 'sukses'): ?>
                <div class="alert alert-success" style="margin-bottom: 15px;">Transaksi berhasil diproses!</div>
            <?php endif; ?>
            
            <?php 
            // Ini berfungsi untuk menampilkan kotak info "Menampilkan hasil pencarian untuk: [keyword]" kalau user lagi nyari sesuatu
            tampilkan_alert_pencarian($keyword, 'konfirmasi.php'); 
            ?>

            <table class="tabel-data">
                <thead>
                    <tr>
                        <th>TANGGAL</th>
                        <th>NAMA ANGGOTA</th>
                        <th>BUKU & PAKET</th>
                        <th>BIAYA</th>
                        <th>BUKTI BAYAR</th>
                        <th>STATUS</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    // Ini berfungsi untuk melakukan perulangan (looping), mencetak setiap baris data transaksi ke dalam tabel
                    foreach ($daftar_transaksi as $trx): ?>
                    <tr>
                        <td><?php echo $trx['tanggal_pinjam'] ? date('d/m/Y', strtotime($trx['tanggal_pinjam'])) : '-'; ?></td>
                        
                        <td style="font-weight: bold;"><?php echo htmlspecialchars($trx['nama_lengkap']); ?></td>
                        
                        <td>
                            <div style="color: #1A0A2E; font-weight: bold;"><?php echo htmlspecialchars($trx['judul']); ?></div>
                            <div style="font-size: 12px; color: #8A6BAE;"><?php echo htmlspecialchars($trx['nama_paket']); ?></div>
                        </td>
                        
                        <td style="font-weight: bold; color: #059669;">Rp <?php echo number_format($trx['total_biaya'], 0, ',', '.'); ?></td>
                        
                        <td>
                            <?php 
                            // Ini berfungsi mengecek apakah kolom bukti_pembayaran ada isinya. Kalau ada, tampilkan tombol untuk melihat gambar
                            if ($trx['bukti_pembayaran']): ?>
                                <a href="../uploads/bukti/<?php echo htmlspecialchars($trx['bukti_pembayaran']); ?>" target="_blank" style="background: #E0E7FF; color: #4338CA; padding: 4px 10px; border-radius: 4px; text-decoration: none; font-size: 12px; font-weight: bold;"><i class="fa-solid fa-image"></i> Cek Bukti</a>
                            <?php else: ?>
                                <span style="color: #9CA3AF; font-size: 12px;">Tidak ada</span>
                            <?php endif; ?>
                        </td>

                        <td>
                            <?php 
                            // Ini berfungsi untuk membuat label (badge) berwarna sesuai dengan kondisi status transaksinya
                            if ($trx['status_akses'] == 'Menunggu Konfirmasi'): ?>
                                <span style="background: #FEF3C7; color: #92400E; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold;">Menunggu ACC</span>
                            <?php elseif ($trx['status_akses'] == 'Aktif'): ?>
                                <span style="background: #D1FAE5; color: #065F46; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold;">Dipinjam (Aktif)</span>
                            <?php else: ?>
                                <span style="background: #FEE2E2; color: #991B1B; padding: 4px 8px; border-radius: 4px; font-size: 12px; font-weight: bold;"><?php echo htmlspecialchars($trx['status_akses']); ?></span>
                            <?php endif; ?>
                        </td>

                        <td style="display: flex; gap: 8px;">
                            <?php 
                            // Ini berfungsi untuk membatasi aksi. Tombol ACC dan Tolak hanya muncul jika status transaksinya masih menunggu konfirmasi
                            if ($trx['status_akses'] == 'Menunggu Konfirmasi'): ?>
                                <a href="proses_transaksi.php?id=<?php echo $trx['id_transaksi']; ?>&aksi=acc" onclick="return confirm('Verifikasi pembayaran dan ACC pinjaman ini?');" style="background: #10B981; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px; font-weight: bold;"><i class="fa-solid fa-check"></i> ACC</a>
                                
                                <a href="proses_transaksi.php?id=<?php echo $trx['id_transaksi']; ?>&aksi=tolak" onclick="return confirm('Tolak transaksi ini?');" style="background: #EF4444; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px; font-weight: bold;"><i class="fa-solid fa-xmark"></i> Tolak</a>
                            <?php else: ?>
                                <span style="color: #9CA3AF; font-size: 12px; font-style: italic;">Selesai diproses</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php 
                    // Ini berfungsi untuk menampilkan keterangan "Belum ada data transaksi" jika array $daftar_transaksi itu kosong
                    if(empty($daftar_transaksi)): ?>
                    <tr><td colspan="7" style="text-align: center; color: #8A6BAE;">Belum ada data transaksi.</td></tr>
                    <?php endif; ?>
                </tbody>
            </table>

            <?php 
            // Bagian Pagination (Angka navigasi halaman)
            if ($total_halaman > 1): ?>
                <div class="pagination-container" style="margin-top: 20px; display: flex; justify-content: center; gap: 8px;">
                    <?php 
                    // Ini berfungsi untuk mencetak angka halaman berjejer sesuai jumlah $total_halaman (contoh: 1 2 3 4)
                    for($i = 1; $i <= $total_halaman; $i++): ?>
                        <?php 
                            // Ini berfungsi untuk menjaga agar keyword pencarian tidak hilang saat kita ganti-ganti halaman
                            $link_halaman = empty($keyword) ? "?halaman=$i" : "?q=" . urlencode($keyword) . "&halaman=$i"; 
                            
                            // Ini berfungsi untuk memberikan warna berbeda pada tombol angka halaman yang sedang aktif dibuka user saat ini
                            $is_active = ($i == $halaman_aktif);
                            $bg_color = $is_active ? '#7B2FBE' : '#fff';
                            $text_color = $is_active ? '#fff' : '#7B2FBE';
                        ?>
                        <a href="<?php echo $link_halaman; ?>" style="padding: 8px 14px; text-decoration: none; border: 1px solid #C084FC; border-radius: 5px; background-color: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; font-weight: bold; transition: 0.3s;">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>