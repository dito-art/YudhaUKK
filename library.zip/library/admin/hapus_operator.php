<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_operator = trim($_GET['id']);

    try {

        $stmt_operator = $pdo->prepare("DELETE FROM operator WHERE id = ?");
        $stmt_operator->execute([$id_operator]);

        // Kembalikan ke halaman kelola dengan membawa pesan sukses
        header("Location: kelola_operator.php?pesan=hapus_sukses");
        exit;

    } catch(PDOException $e) {
        die("Error sistem: " . $e->getMessage());
    }
} else {
    header("Location: kelola_operator.php");
    exit;
}
?>