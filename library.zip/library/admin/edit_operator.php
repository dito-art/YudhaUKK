<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$id_operator = $_GET['id'] ?? '';

if (!is_numeric($id_operator)) {
    header("Location: kelola_operator.php");
    exit;
}
$pesan = '';

$stmt = $pdo->prepare("SELECT * FROM operator WHERE id = ?");
$stmt->execute([$id_operator]);
$operator_lama = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$operator_lama) {
    die("Data operator tidak ditemukan.");
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $namaLengkap = $_POST['namaLengkap'] ?? '';
    $username = $_POST['user'] ?? '';
    $noTelp = $_POST['noTelp'] ?? '';
    $role = $_POST['role'] ?? '';
    $cek = $pdo->prepare("SELECT id FROM operator WHERE username = ? AND id != ?");
$cek->execute([$username, $id_operator]);

if ($cek->rowCount() > 0) {
    $pesan = "<div style='color: #ec0505; background: #EDE9FE; padding: 10px; border-radius: 4px; margin-bottom: 15px;'>Username sudah digunakan!</div>";
}else{
    if (!empty($_POST['pw'])) {
        $password = password_hash($_POST['pw'], PASSWORD_DEFAULT);
    } else {
        $password = $operator_lama['password'];
    }

    $query_update = "UPDATE operator SET nama_lengkap = ?, username = ?, password = ?, no_telp = ?, role = ? WHERE id = ?";
    $stmt_update = $pdo->prepare($query_update);
    $stmt_update->execute([$namaLengkap, $username, $password, $noTelp, $role, $id_operator]);

    header("Location: kelola_operator.php?pesan=edit_sukses");
    exit;
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Operator</title>
    <link rel="stylesheet" href="../assets/css/tambah_buku.css">
</head>
<body>
    <div class="form-container">
        <h2>Edit Data Operator</h2>
        <?php echo $pesan; ?>
        
        <form action="" method="POST">
            <div class="form-group"><label>Nama Lengkap</label><input type="text" name="namaLengkap" value="<?php echo htmlspecialchars($operator_lama['nama_lengkap']); ?>" required></div>
            <div class="form-group"><label>Username</label><input type="text" name="user" value="<?php echo htmlspecialchars($operator_lama['username']); ?>" required></div>
            <div class="form-group"><label>Password</label><input type="password" name="pw" placeholder="Kosongkan jika tidak diubah"></div>
            <div class="form-group"><label>No Telp</label><input type="text" name="noTelp" value="<?php echo htmlspecialchars($operator_lama['no_telp']); ?>" required></div>
            <div class="form-group">
                <label>Role</label>
                <select name="role" id="role">
                    <option value="admin" <?php if($operator_lama['role'] == 'admin') echo 'selected'; ?>>Admin</option>
                    <option value="petugas" <?php if($operator_lama['role'] == 'petugas') echo 'selected'; ?>>Petugas</option>
                </select>
            </div>
            
            <button type="submit" class="btn-submit">Simpan</button>
            <a href="kelola_operator.php" style="margin-left: 10px; color: #8A6BAE; text-decoration: none;">Batal</a>
        </form>
    </div>
</body>
</html>