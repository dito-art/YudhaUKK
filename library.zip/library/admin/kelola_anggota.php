<?php
require_once '../config/koneksi.php';
require_once '../auth/auth_guard.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

try {
    // 1. Panggil fungsi untuk mendapatkan keyword
    $keyword = dapatkan_keyword();

    // 2. KONFIGURASI PAGINATION
    $batas = 5; // Jumlah baris per halaman (bisa diubah)
    $halaman_aktif = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1; // Cek URL '?halaman='
    $awal_data = ($batas * $halaman_aktif) - $batas; // Menentukan titik mulai data

    // 2. Logika query tetap di sini karena spesifik untuk tabel kategori
    if (!empty($keyword)) {
        // Hitung total data untuk pencarian
        $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM anggota WHERE nama_lengkap LIKE :keyword_nama_lengkap OR username LIKE :keyword_username");
        $stmt_count->execute([
            'keyword_nama_lengkap' => "%$keyword%",
            'keyword_username' => "%$keyword%"
            ]);
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT (Gunakan bindValue agar tipe datanya terjamin Integer)
        $query = "SELECT * FROM anggota WHERE nama_lengkap LIKE :keyword_nama_lengkap OR username LIKE :keyword_username ORDER BY id_anggota DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':keyword_nama_lengkap', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':keyword_username', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    } else {
        // Hitung total seluruh data
        $stmt_count = $pdo->query("SELECT COUNT(*) FROM anggota");
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT
        $query = "SELECT * FROM anggota ORDER BY id_anggota DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    }

    $total_halaman = ceil($total_data / $batas);
    $daftar_anggota = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Anggota</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
</head>
<body>
    <?php 
    $base_path = '../';
    $search_action = 'kelola_anggota.php';
    $search_placeholder = 'Cari nama atau username...';
    include '../includes/navbar.php'; 
    ?>
    <div class="main-wrapper">
    <?php include '../includes/sidebar.php'; ?>

        <main class="content-area">
            
            <div class="header-aksi">
                <h2 style="color: #1A0A2E;">Kelola Data Anggota</h2>
            </div>

            <?php tampilkan_alert_pencarian($keyword, 'kelola_anggota.php'); ?>


            <table class="tabel-data">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>NAMA LENGKAP</th>
                        <th>USERNAME</th>
                        <th>NIS</th>
                        <th>KELAS & JURUSAN</th>
                        <th>NO TELP</th>
                        <th>STATUS</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        $no = $awal_data + 1;
                        foreach ($daftar_anggota as $anggota): 
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td style="font-weight: bold; color: #1A0A2E;"><?php echo htmlspecialchars($anggota['nama_lengkap']); ?></td>
                        <td style="color: #5B3F7A;"><?php echo htmlspecialchars($anggota['username']); ?></td>
                        <td><?php echo htmlspecialchars($anggota['nis']); ?></td>
                        <td style="font-weight: bold; color: #1A0A2E;"><?= htmlspecialchars($anggota['kelas'] . ' ' . $anggota['jurusan']); ?></td>
                        <td><?php echo htmlspecialchars($anggota['no_telp']); ?></td>
                        <td>
                            <?php if ($anggota['status'] == 'Aktif'): ?>
                                <span style="background: #D1FAE5; color: #065F46; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">Aktif</span>
                            <?php else: ?>
                                <span style="background: #FEE2E2; color: #991B1B; padding: 4px 10px; border-radius: 20px; font-size: 12px; font-weight: bold;">Nonaktif</span>
                            <?php endif; ?>
                        </td>
                        <td style="display: flex; gap: 8px;">
                            <a href="edit_anggota.php?id=<?php echo $anggota['id_anggota']; ?>" class="btn-edit"><i class="fa-solid fa-pen"></i> Edit</a>
                            
                            <?php if ($anggota['status'] == 'Aktif'): ?>
                                <a href="status_anggota.php?id=<?php echo $anggota['id_anggota']; ?>&status=nonaktif" class="btn-hapus" onclick="return confirm('Yakin ingin memblokir akses anggota ini?');" style="background: #EF4444; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px; font-weight: bold;"><i class="fa-solid fa-ban"></i> Blokir</a>
                            <?php else: ?>
                                <a href="status_anggota.php?id=<?php echo $anggota['id_anggota']; ?>&status=aktif" class="btn-tambah" onclick="return confirm('Yakin ingin memulihkan akses anggota ini?');" style="background: #10B981; color: white; padding: 6px 12px; border-radius: 4px; text-decoration: none; font-size: 12px; font-weight: bold;"><i class="fa-solid fa-check"></i> Aktifkan</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?> 
                    
                    <?php if(empty($daftar_anggota)): ?>
                    <tr>
                        <td colspan="8" style="text-align: center; color: #8A6BAE;">Tidak ada data anggota.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if ($total_halaman > 1): ?>
                <div class="pagination-container" style="margin-top: 20px; display: flex; justify-content: center; gap: 8px;">
                    <?php for($i = 1; $i <= $total_halaman; $i++): ?>
                        <?php 
                            // Pertahankan keyword pencarian di URL jika sedang mencari
                            $link_halaman = empty($keyword) ? "?halaman=$i" : "?q=" . urlencode($keyword) . "&halaman=$i"; 
                            
                            // Cek apakah ini halaman yang sedang aktif untuk pewarnaan
                            $is_active = ($i == $halaman_aktif);
                            $bg_color = $is_active ? '#7B2FBE' : '#fff';
                            $text_color = $is_active ? '#fff' : '#7B2FBE';
                        ?>
                        <a href="<?php echo $link_halaman; ?>" style="padding: 8px 14px; text-decoration: none; border: 1px solid #C084FC; border-radius: 5px; background-color: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; font-weight: bold; transition: 0.3s;">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>

        </main>
    </div>
</body>
</html>