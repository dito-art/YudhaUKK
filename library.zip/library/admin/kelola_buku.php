<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    // Jika petugas mencoba masuk, tendang ke beranda dashboard
    header("Location: index.php");
    exit;
}

try {
    // 1. Panggil fungsi untuk mendapatkan keyword
    $keyword = dapatkan_keyword();

    $batas = 5; // Jumlah baris per halaman (bisa diubah)
    $halaman_aktif = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1; // Cek URL '?halaman='
    $awal_data = ($batas * $halaman_aktif) - $batas; // Menentukan titik mulai data

    // 2. Logika query tetap di sini karena spesifik untuk tabel kategori
    if (!empty($keyword)) {
        $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM buku WHERE judul LIKE :keyword_judul OR penulis LIKE :keyword_penulis");
        $stmt_count->execute([
            'keyword_judul' => "%$keyword%",
            'keyword_penulis' => "%$keyword%"
            ]);
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT (Gunakan bindValue agar tipe datanya terjamin Integer)
        $query = "SELECT * FROM buku WHERE judul LIKE :keyword_judul OR penulis LIKE :keyword_penulis ORDER BY id_buku DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':keyword_judul', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':keyword_penulis', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    } else {
        // Hitung total seluruh data
        $stmt_count = $pdo->query("SELECT COUNT(*) FROM buku");
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT
        $query = "SELECT * FROM buku ORDER BY id_buku DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    }
    
    $total_halaman = ceil($total_data / $batas);
    $daftar_buku = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Buku - Admin Perpus</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
</head>
<body>

    <?php 
    $base_path = '../';
    $search_action = 'kelola_buku.php';
    $search_placeholder = 'Cari judul atau penulis...';
    include '../includes/navbar.php'; 
    ?>

    <div class="main-wrapper">
    <?php include '../includes/sidebar.php'; ?>

        <main class="content-area">
            
            <div class="header-aksi">
                <h2 style="color: #1A0A2E;">Kelola Data Buku</h2>
                <a href="tambah_buku.php" class="btn-tambah"><i class="fa-solid fa-plus"></i> Tambah Buku Baru</a>
            </div>

            <?php tampilkan_alert_pencarian($keyword, 'kelola_buku.php'); ?>


            <table class="tabel-data">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>COVER</th>
                        <th style="min-width: 180px; text-align: center;">JUDUL BUKU</th>
                        <th>PENULIS</th>
                        <th>TAHUN</th>
                        <th style="min-width: 180px; text-align: center;">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = $awal_data + 1;
                    foreach ($daftar_buku as $buku): 
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td>
                            <img src="../uploads/cover/<?php echo htmlspecialchars($buku['cover']); ?>" alt="Cover" class="cover-kecil">
                        </td>
                        <td style="font-weight: bold; color: #1A0A2E;"><?php echo htmlspecialchars($buku['judul']); ?></td>
                        <td style="color: #5B3F7A;"><?php echo htmlspecialchars($buku['penulis']); ?></td>
                        <td><?php echo htmlspecialchars($buku['tahun_terbit']); ?></td>
                        <td style="white-space: nowrap; text-align: center;">
                            <a href="edit_buku.php?id=<?php echo $buku['id_buku']; ?>" class="btn-edit"><i class="fa-solid fa-pen"></i> Edit</a>
                            <a href="hapus_buku.php?id=<?php echo $buku['id_buku']; ?>" class="btn-hapus" onclick="return confirm('Yakin ingin menghapus buku ini beserta file PDF-nya?');"><i class="fa-solid fa-trash"></i> Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if(empty($daftar_buku)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #8A6BAE;">Belum ada data buku.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
             <?php if ($total_halaman > 1): ?>
                <div class="pagination-container" style="margin-top: 20px; display: flex; justify-content: center; gap: 8px;">
                    <?php for($i = 1; $i <= $total_halaman; $i++): ?>
                        <?php 
                            // Pertahankan keyword pencarian di URL jika sedang mencari
                            $link_halaman = empty($keyword) ? "?halaman=$i" : "?q=" . urlencode($keyword) . "&halaman=$i"; 
                            
                            // Cek apakah ini halaman yang sedang aktif untuk pewarnaan
                            $is_active = ($i == $halaman_aktif);
                            $bg_color = $is_active ? '#7B2FBE' : '#fff';
                            $text_color = $is_active ? '#fff' : '#7B2FBE';
                        ?>
                        <a href="<?php echo $link_halaman; ?>" style="padding: 8px 14px; text-decoration: none; border: 1px solid #C084FC; border-radius: 5px; background-color: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; font-weight: bold; transition: 0.3s;">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>

</body>
</html>