<?php
require_once '../config/koneksi.php';
require_once '../auth/auth_guard.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

try {
    // 1. Panggil fungsi untuk mendapatkan keyword
    $keyword = dapatkan_keyword();

    // 2. KONFIGURASI PAGINATION
    $batas = 5; // Jumlah baris per halaman (bisa diubah)
    $halaman_aktif = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1; // Cek URL '?halaman='
    $awal_data = ($batas * $halaman_aktif) - $batas; // Menentukan titik mulai data

    if (!empty($keyword)) {
        $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM operator WHERE nama_lengkap LIKE :keyword_nama_lengkap OR username LIKE :keyword_username");
        $stmt_count->execute([
            'keyword_nama_lengkap' => "%$keyword%",
            'keyword_username' => "%$keyword%"
            ]);
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT (Gunakan bindValue agar tipe datanya terjamin Integer)
        $query = "SELECT * FROM operator WHERE nama_lengkap LIKE :keyword_nama_lengkap OR username LIKE :keyword_username ORDER BY id DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':keyword_nama_lengkap', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':keyword_username', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    } else {
        // Hitung total seluruh data
        $stmt_count = $pdo->query("SELECT COUNT(*) FROM operator");
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT
        $query = "SELECT * FROM operator ORDER BY id DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    }
    
    $total_halaman = ceil($total_data / $batas);
    $daftar_operator = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Operator</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
</head>
<body>
    <?php 
    $base_path = '../';
    $search_action = 'kelola_operator.php';
    $search_placeholder = 'Cari nama atau username...';
    include '../includes/navbar.php'; 
    ?>
    <div class="main-wrapper">
    <?php include '../includes/sidebar.php'; ?>

        <main class="content-area">
            
            <div class="header-aksi">
                <h2 style="color: #1A0A2E;">Kelola Data Operator</h2>
                <a href="tambah_operator.php" class="btn-tambah"><i class="fa-solid fa-plus"></i> Tambah Operator</a>
            </div>

            <?php tampilkan_alert_pencarian($keyword, 'kelola_operator.php'); ?>


            <table class="tabel-data">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>NAMA OPERATOR</th>
                        <th>USERNAME</th>
                        <th>NO TELP</th>
                        <th>ROLE</th>
                        <th>AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = $awal_data + 1;
                    foreach ($daftar_operator as $operator): 
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td style="font-weight: bold; color: #1A0A2E;"><?php echo htmlspecialchars($operator['nama_lengkap']); ?></td>
                        <td style="color: #5B3F7A;"><?php echo htmlspecialchars($operator['username']); ?></td>
                        <td><?php echo htmlspecialchars($operator['no_telp']); ?></td>
                        <td><?php echo htmlspecialchars($operator['role']); ?></td>
                        <td>
                            <a href="edit_operator.php?id=<?php echo $operator['id']; ?>" class="btn-edit"><i class="fa-solid fa-pen"></i> Edit</a>
                            <a href="hapus_operator.php?id=<?php echo $operator['id']; ?>" class="btn-hapus" onclick="return confirm('Yakin ingin menghapus?');"><i class="fa-solid fa-trash"></i> Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?> 
                    
                    <?php if(empty($daftar_operator)): ?>
                    <tr>
                        <td colspan="6" style="text-align: center; color: #8A6BAE;">Tidak ada data operator.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if ($total_halaman > 1): ?>
                <div class="pagination-container" style="margin-top: 20px; display: flex; justify-content: center; gap: 8px;">
                    <?php for($i = 1; $i <= $total_halaman; $i++): ?>
                        <?php 
                            // Pertahankan keyword pencarian di URL jika sedang mencari
                            $link_halaman = empty($keyword) ? "?halaman=$i" : "?q=" . urlencode($keyword) . "&halaman=$i"; 
                            
                            // Cek apakah ini halaman yang sedang aktif untuk pewarnaan
                            $is_active = ($i == $halaman_aktif);
                            $bg_color = $is_active ? '#7B2FBE' : '#fff';
                            $text_color = $is_active ? '#fff' : '#7B2FBE';
                        ?>
                        <a href="<?php echo $link_halaman; ?>" style="padding: 8px 14px; text-decoration: none; border: 1px solid #C084FC; border-radius: 5px; background-color: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; font-weight: bold; transition: 0.3s;">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>