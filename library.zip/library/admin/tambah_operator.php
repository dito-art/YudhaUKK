<?php
require_once '../config/koneksi.php';
require_once '../auth/auth_guard.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$pesan = '';

if($_SERVER["REQUEST_METHOD"] == "POST"){
    $namaLengkap = $_POST['namaLengkap'] ?? '';
    $username = $_POST['user'] ?? '';
    $password = password_hash($_POST['pw'] ?? '', PASSWORD_DEFAULT);
    $noTelp = $_POST['noTelp'] ?? '';
    $role = $_POST['role'] ?? '';

    try {
    $cek = $pdo->prepare("SELECT * FROM operator WHERE username = ?");
    $cek->execute([$username]);

    if ($cek->rowCount() > 0) {
        $pesan = "<div style='color: #ec0505; background: #EDE9FE; padding: 10px; border-radius: 4px; margin-bottom: 15px;'>Username sudah digunakan!</div>";
    } else {
        $query = "INSERT INTO operator (nama_lengkap, username, password, no_telp, role) 
                  VALUES (?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$namaLengkap, $username, $password, $noTelp, $role]);

        $pesan = "<div style='color: #4A1060; background: #EDE9FE; padding: 10px; border-radius: 4px; margin-bottom: 15px;'>Operator berhasil ditambahkan!</div>";
    }
    } catch(PDOException $e) {
    $pesan = "<div style='color: #c62828; background: #ffebee; padding: 10px; border-radius: 4px; margin-bottom: 15px;'>Gagal menambahkan operator: " . $e->getMessage() . "</div>";
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Operator</title>
    <link rel="stylesheet" href="../assets/css/tambah_buku.css">
</head>
<body>
    <div class="form-container">
        <h2>Tambah Operator</h2>
        <?php echo $pesan; ?>
        
        <form action="" method="POST">
            <div class="form-group"><label>Nama Lengkap</label><input type="text" name="namaLengkap" required></div>
            <div class="form-group"><label>Username</label><input type="text" name="user" required></div>
            <div class="form-group"><label>Password</label><input type="password" name="pw" required></div>
            <div class="form-group"><label>No Telp</label><input type="text" name="noTelp" required></div>
            <div class="form-group"><label>Role</label>
                <select name="role" id="role">
                    <option value="admin">Admin</option>
                    <option value="petugas">Petugas</option>
                </select>
            </div>
            
            <button type="submit" class="btn-submit">Simpan</button>
            <a href="kelola_operator.php" style="margin-left: 10px; color: #8A6BAE; text-decoration: none;">Batal</a>
        </form>
    </div>
</body>
</html>