<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Satpam Pengecek Login
if (!isset($_SESSION['id_user']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'petugas')) {
    header("Location: ../auth/login.php");
    exit;
}

try {
    // 1. Hitung Total Buku
    $stmt_buku = $pdo->query("SELECT COUNT(*) FROM buku");
    $total_buku = $stmt_buku->fetchColumn();

    // 2. Hitung Total Anggota
    $stmt_anggota = $pdo->query("SELECT COUNT(*) FROM anggota");
    $total_anggota = $stmt_anggota->fetchColumn();

    // 3. Hitung Peminjaman yang Menunggu Konfirmasi
    $stmt_menunggu = $pdo->query("SELECT COUNT(*) FROM transaksi WHERE status_akses = 'Menunggu Konfirmasi'");
    $total_menunggu = $stmt_menunggu->fetchColumn();

} catch(PDOException $e) {
    die("Error mengambil data dashboard: " . $e->getMessage());
}

$role = $_SESSION['role'];
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/indexAdmin.css">
</head>
<body>

    <?php
    $base_path = '../';
    include '../includes/navbar.php'; ?>

    <div class="main-wrapper">
        <?php include '../includes/sidebar.php'; ?>

        <main class="content-area">
            <h2 style="margin-bottom: 10px; color: #1A0A2E;">Selamat datang, <?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?>!</h2>
            <p style="color: #8A6BAE; margin-bottom: 30px;">Pilih menu di samping untuk mulai mengelola perpustakaan.</p>

            <div class="dashboard-cards">
                <div class="card" style="border-left-color: #7B2FBE;">
                    <h3><i class="fa-solid fa-book"></i>Total Buku</h3>
                    <div class="angka"><?php echo $total_buku; ?></div>
                </div>
                
                <?php if ($role === 'admin'): ?>
                <div class="card" style="border-left-color: #A855F7;">
                    <h3><i class="fa-solid fa-users"></i>Total Anggota</h3>
                    <div class="angka"><?php echo $total_anggota; ?></div>
                </div>
                <?php endif; ?>

                <div class="card" style="border-left-color: #C084FC;">
                    <h3><i class="fa-solid fa-bell"></i>Menunggu Konfirmasi</h3>
                    <div class="angka"><?php echo $total_menunggu; ?></div>
                </div>
            </div>
        </main>
    </div>

</body>
</html>