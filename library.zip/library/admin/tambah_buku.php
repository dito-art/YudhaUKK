<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$pesan = '';

try {
    $stmt_kategori = $pdo->query("SELECT * FROM kategori ORDER BY nama_kategori ASC");
    $daftar_kategori = $stmt_kategori->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error mengambil kategori: " . $e->getMessage());
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $judul = $_POST['judul_buku'];
    $penulis = $_POST['penulis'];
    $penerbit = $_POST['penerbit'];
    $tahun = $_POST['tahun_terbit'];
    $halaman = $_POST['jumlah_halaman'];
    $blurb = $_POST['blurb'];
    $kategori_terpilih = isset($_POST['kategori']) ? $_POST['kategori'] : [];

    $nama_file_cover = '';
    $nama_file_pdf = '';

    if (isset($_FILES['cover_buku']) && $_FILES['cover_buku']['error'] == 0) {
        $nama_file_cover = time() . '_' . $_FILES['cover_buku']['name'];
        move_uploaded_file($_FILES['cover_buku']['tmp_name'], '../uploads/cover/' . $nama_file_cover);
    }

    if (isset($_FILES['file_pdf']) && $_FILES['file_pdf']['error'] == 0) {
        $nama_file_pdf = time() . '_' . $_FILES['file_pdf']['name'];
        move_uploaded_file($_FILES['file_pdf']['tmp_name'], '../uploads/isi-buku/' . $nama_file_pdf);
    }

    try {
        $pdo->beginTransaction();

        $query = "INSERT INTO buku (judul, penulis, penerbit, tahun_terbit, jumlah_halaman, blurb, cover, isi_buku) 
                  VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt = $pdo->prepare($query);
        $stmt->execute([$judul, $penulis, $penerbit, $tahun, $halaman, $blurb, $nama_file_cover, $nama_file_pdf]);
        
        $id_buku_baru = $pdo->lastInsertId();

        if (!empty($kategori_terpilih)) {
            $query_pivot = "INSERT INTO kategori_buku (id_buku, id_kategori) VALUES (?, ?)";
            $stmt_pivot = $pdo->prepare($query_pivot);
            foreach ($kategori_terpilih as $id_kategori) {
                $stmt_pivot->execute([$id_buku_baru, $id_kategori]);
            }
        }

        $pdo->commit();
        $pesan = "<div style='color: #4A1060; background: #EDE9FE; padding: 10px; border-radius: 4px; margin-bottom: 15px;'>Buku berhasil ditambahkan!</div>";
        
    } catch(PDOException $e) {
        $pdo->rollBack();
        $pesan = "<div style='color: #c62828; background: #ffebee; padding: 10px; border-radius: 4px; margin-bottom: 15px;'>Gagal menambahkan buku: " . $e->getMessage() . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Tambah Buku</title>
    <link rel="stylesheet" href="../assets/css/tambah_buku.css">
</head>
<body>
    <div class="form-container">
        <h2>Tambah Buku Digital Baru</h2>
        <?php echo $pesan; ?>
        
        <form action="" method="POST" enctype="multipart/form-data">
            <div class="form-group"><label>Judul Buku</label><input type="text" name="judul_buku" required></div>
            <div class="form-group"><label>Penulis</label><input type="text" name="penulis" required></div>
            <div class="form-group"><label>Penerbit</label><input type="text" name="penerbit" required></div>
            <div class="form-group"><label>Tahun Terbit</label><input type="number" name="tahun_terbit" required></div>
            <div class="form-group"><label>Jumlah Halaman</label><input type="number" name="jumlah_halaman" required></div>
            <div class="form-group"><label>Blurb (Sinopsis Singkat)</label><textarea name="blurb" rows="4" required></textarea></div>
            
            <div class="form-group">
                <label>Pilih Kategori Buku</label>
                <div class="kategori-container">
                    <?php foreach ($daftar_kategori as $kat): ?>
                        <label class="kategori-item">
                            <input type="checkbox" name="kategori[]" value="<?php echo $kat['id_kategori']; ?>">
                            <?php echo htmlspecialchars($kat['nama_kategori']); ?>
                        </label>
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="form-group"><label>Upload Cover Buku (JPG/PNG)</label><input type="file" name="cover_buku" accept="image/*" required></div>
            <div class="form-group"><label>Upload File Buku (PDF)</label><input type="file" name="file_pdf" accept="application/pdf" required></div>
            
            <button type="submit" class="btn-submit">Simpan Buku</button>
            <a href="kelola_buku.php" style="margin-left: 10px; color: #8A6BAE; text-decoration: none;">Batal</a>
        </form>
    </div>
</body>
</html>