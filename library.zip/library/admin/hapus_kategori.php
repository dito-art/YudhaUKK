<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Pastikan hanya admin yang bisa akses
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_kategori = trim($_GET['id']);

    try {
        // 1. HAPUS RELASI DULU
        // Hapus catatan di tabel penghubung (kategori_buku)
        $stmt_relasi = $pdo->prepare("DELETE FROM kategori_buku WHERE id_kategori = ?");
        $stmt_relasi->execute([$id_kategori]);

        // 2. HAPUS KATEGORI UTAMA
        // Setelah tali relasinya putus, baru kategori di tabel utama aman untuk dihapus
        $stmt_kategori = $pdo->prepare("DELETE FROM kategori WHERE id_kategori = ?");
        $stmt_kategori->execute([$id_kategori]);

        // Kembalikan ke halaman kelola dengan membawa pesan sukses
        header("Location: kelola_kategori.php?pesan=hapus_sukses");
        exit;

    } catch(PDOException $e) {
        die("Error sistem: " . $e->getMessage());
    }
} else {
    header("Location: kelola_kategori.php");
    exit;
}
?>