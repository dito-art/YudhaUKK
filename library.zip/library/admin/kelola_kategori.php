<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';
require_once '../includes/functions.php';

if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$pesan = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['tambah_kategori'])) {
    // 1. Ambil input dan hilangkan spasi berlebih di awal/akhir
    $nama_kategori = trim($_POST['nama_kategori']);
    
    // 2. Format teks: Kecilkan semua huruf, lalu kapitalisasi tiap kata (pemisah: spasi dan strip)
    $nama_kategori = ucwords(strtolower($nama_kategori), " -");
    
    // Sesudah
if (!empty($nama_kategori)) {
    try {
        $stmt_cek = $pdo->prepare("SELECT COUNT(*) FROM kategori WHERE nama_kategori = :nama");
        $stmt_cek->execute(['nama' => $nama_kategori]);
        if ($stmt_cek->fetchColumn() > 0) {
            $pesan = "<div class='alert' style='background:#ffebee; color:#c62828; border:1px solid #f5c6cb;'>Kategori sudah ada!</div>";
        } else {
            $query = "INSERT INTO kategori (nama_kategori) VALUES (?)";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$nama_kategori]);
            $pesan = "<div class='alert alert-success'>Kategori berhasil ditambahkan!</div>";
        }
    } catch(PDOException $e) {
        $pesan = "<div class='alert' style='background:#ffebee; color:#c62828; border:1px solid #f5c6cb;'>Gagal: " . $e->getMessage() . "</div>";
    }
}
}
// --- LOGIKA EDIT KATEGORI ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['edit_kategori'])) {
    $id_kategori = $_POST['id_kategori'];
    $nama_kategori = trim($_POST['nama_kategori']);
    $nama_kategori = ucwords(strtolower($nama_kategori), " -"); // Format otomatis
    
    // Sesudah
if (!empty($nama_kategori)) {
    try {
        // Cek duplikat tapi kecualikan ID milik diri sendiri
        $stmt_cek = $pdo->prepare("SELECT COUNT(*) FROM kategori WHERE nama_kategori = :nama AND id_kategori != :id");
        $stmt_cek->execute(['nama' => $nama_kategori, 'id' => $id_kategori]);
        if ($stmt_cek->fetchColumn() > 0) {
            $pesan = "<div class='alert' style='background:#ffebee; color:#c62828; border:1px solid #f5c6cb; margin-bottom: 15px;'>Gagal: Kategori sudah ada!</div>";
        } else {
            $query = "UPDATE kategori SET nama_kategori = ? WHERE id_kategori = ?";
            $stmt = $pdo->prepare($query);
            $stmt->execute([$nama_kategori, $id_kategori]);
            $pesan = "<div class='alert alert-success' style='margin-bottom: 15px;'>Kategori berhasil diperbarui!</div>";
        }
    } catch(PDOException $e) {
        $pesan = "<div class='alert' style='background:#ffebee; color:#c62828; border:1px solid #f5c6cb; margin-bottom: 15px;'>Gagal mengedit: " . $e->getMessage() . "</div>";
    }
}
}

// --- TANGKAP PESAN DARI URL (Misal setelah hapus) ---
if (isset($_GET['pesan']) && $_GET['pesan'] == 'hapus_sukses') {
    $pesan = "<div class='alert alert-success' style='margin-bottom: 15px;'>Kategori berhasil dihapus!</div>";
}
try {
    // 1. Panggil fungsi untuk mendapatkan keyword
    $keyword = dapatkan_keyword();

    // 2. KONFIGURASI PAGINATION
    $batas = 5; // <--- Kamu bisa ganti angka ini jadi 10 atau 15 nanti
    $halaman_aktif = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
    $awal_data = ($batas * $halaman_aktif) - $batas;

    // 3. LOGIKA QUERY DENGAN LIMIT
    if (!empty($keyword)) {
        // Hitung total data untuk pencarian
        $stmt_count = $pdo->prepare("SELECT COUNT(*) FROM kategori WHERE nama_kategori LIKE :keyword");
        $stmt_count->execute(['keyword' => "%$keyword%"]);
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT (Gunakan bindValue agar tipe datanya terjamin Integer)
        $query = "SELECT * FROM kategori WHERE nama_kategori LIKE :keyword ORDER BY id_kategori DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':keyword', "%$keyword%", PDO::PARAM_STR);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    } else {
        // Hitung total seluruh data
        $stmt_count = $pdo->query("SELECT COUNT(*) FROM kategori");
        $total_data = $stmt_count->fetchColumn();

        // Ambil data dengan LIMIT
        $query = "SELECT * FROM kategori ORDER BY id_kategori DESC LIMIT :awal, :batas";
        $stmt = $pdo->prepare($query);
        $stmt->bindValue(':awal', $awal_data, PDO::PARAM_INT);
        $stmt->bindValue(':batas', $batas, PDO::PARAM_INT);
        $stmt->execute();
    }
    
    // Hitung total halaman yang dibutuhkan
    $total_halaman = ceil($total_data / $batas);
    $daftar_kategori = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Kelola Kategori - Admin Perpus</title>
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kelola_kategori.css">
    <link rel="stylesheet" href="../libraries/css/all.min.css">
</head>
<body>

    <?php
    $base_path = '../';
    $search_action = 'kelola_kategori.php';
    $search_placeholder = 'Cari nama kategori...';
    include '../includes/navbar.php';
    ?>

    <div class="main-wrapper">
    <?php include '../includes/sidebar.php'; ?>

        <main class="content-area">
            
            <div class="header-aksi">
                <h2 style="color: #1A0A2E;">Kelola Kategori Buku</h2>
                <button onclick="bukaModal()" class="btn-tambah"><i class="fa-solid fa-plus"></i> Tambah Kategori</button>
            </div>

            <?php tampilkan_alert_pencarian($keyword, 'kelola_kategori.php'); ?>

            <?php echo $pesan; ?>

            <table class="tabel-data">
                <thead>
                    <tr>
                        <th width="10%">NO</th>
                        <th width="60%">NAMA KATEGORI</th>
                        <th width="30%">AKSI</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = $awal_data + 1;
                    foreach ($daftar_kategori as $kat): 
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td>
                        <td style="font-weight: bold; color: #1A0A2E;"><?php echo htmlspecialchars($kat['nama_kategori']); ?></td>
                        <td>
                            <a href="javascript:void(0);" class="btn-edit" onclick="bukaModalEdit(<?php echo $kat['id_kategori']; ?>, '<?php echo addslashes(htmlspecialchars($kat['nama_kategori'])); ?>')"><i class="fa-solid fa-pen"></i> Edit</a>
                            <a href="hapus_kategori.php?id=<?php echo $kat['id_kategori']; ?>" class="btn-hapus" onclick="return confirm('Yakin ingin menghapus kategori ini?');"><i class="fa-solid fa-trash"></i> Hapus</a>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    
                    <?php if(empty($daftar_kategori)): ?>
                    <tr>
                        <td colspan="3" style="text-align: center; color: #8A6BAE;">Belum ada data kategori.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            <?php if ($total_halaman > 1): ?>
            <div class="pagination-container" style="margin-top: 20px; display: flex; justify-content: center; gap: 8px;">
                <?php for($i = 1; $i <= $total_halaman; $i++): ?>
                    <?php 
                        // Pertahankan keyword pencarian di URL jika sedang mencari
                        $link_halaman = empty($keyword) ? "?halaman=$i" : "?q=" . urlencode($keyword) . "&halaman=$i"; 
                        
                        // Cek apakah ini halaman yang sedang aktif
                        $is_active = ($i == $halaman_aktif);
                        $bg_color = $is_active ? '#7B2FBE' : '#fff';
                        $text_color = $is_active ? '#fff' : '#7B2FBE';
                    ?>
                    <a href="<?php echo $link_halaman; ?>" style="padding: 8px 14px; text-decoration: none; border: 1px solid #C084FC; border-radius: 5px; background-color: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; font-weight: bold; transition: 0.3s;">
                        <?php echo $i; ?>
                    </a>
                <?php endfor; ?>
            </div>
            <?php endif; ?>
        </main>
    </div>

    <div id="modalTambah" class="modal-overlay">
        <div class="modal-content">
            <button class="close-btn" onclick="tutupModal()">&times;</button>
            
            <h3 style="color: #1A0A2E; border-bottom: 1px solid #EDE9FE; padding-bottom: 10px;">Tambah Kategori Baru</h3>
            
            <form action="" method="POST">
                <div class="form-group">
                    <label style="display: block; margin-bottom: 5px; color: #5B3F7A; font-weight: bold;">Nama Kategori</label>
                    <input type="text" name="nama_kategori" placeholder="Contoh: Fiksi Ilmiah" required>
                </div>
                <button type="submit" name="tambah_kategori" class="btn-simpan">Simpan Kategori</button>
            </form>
        </div>
    </div>
    <div id="modalEdit" class="modal-overlay" style="display: none;">
        <div class="modal-content">
            <button class="close-btn" onclick="tutupModalEdit()">&times;</button>
            
            <h3 style="color: #1A0A2E; border-bottom: 1px solid #EDE9FE; padding-bottom: 10px;">Edit Kategori</h3>
            
            <form action="" method="POST">
                <input type="hidden" name="id_kategori" id="edit_id_kategori">
                
                <div class="form-group">
                    <label style="display: block; margin-bottom: 5px; color: #5B3F7A; font-weight: bold;">Nama Kategori Baru</label>
                    <input type="text" name="nama_kategori" id="edit_nama_kategori" required>
                </div>
                <button type="submit" name="edit_kategori" class="btn-simpan">Simpan Perubahan</button>
            </form>
        </div>
    </div>

    <script>
        // Fungsi Modal Tambah
        function bukaModal() {
            document.getElementById("modalTambah").style.display = "flex";
        }
        function tutupModal() {
            document.getElementById("modalTambah").style.display = "none";
        }

        // Fungsi Modal Edit
        function bukaModalEdit(id, nama_sekarang) {
            // Isi form edit secara otomatis dengan data lama
            document.getElementById("edit_id_kategori").value = id;
            document.getElementById("edit_nama_kategori").value = nama_sekarang;
            // Tampilkan modal
            document.getElementById("modalEdit").style.display = "flex";
        }
        function tutupModalEdit() {
            document.getElementById("modalEdit").style.display = "none";
        }

        // Menutup modal jika user mengklik area luar kotak form
        window.onclick = function(event) {
            var modalTambah = document.getElementById("modalTambah");
            var modalEdit = document.getElementById("modalEdit");
            if (event.target == modalTambah) {
                modalTambah.style.display = "none";
            }
            if (event.target == modalEdit) {
                modalEdit.style.display = "none";
            }
        }
    </script>

</body>
</html>