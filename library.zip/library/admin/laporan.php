<?php
// Ini berfungsi untuk memanggil file-file penting seperti pengecekan login, koneksi ke database, dan fungsi tambahan
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';
require_once '../includes/functions.php';

// Ini berfungsi untuk melindungi halaman. Hanya Admin dan Petugas yang bisa melihat laporan ini. Kalau bukan, langsung ditendang ke halaman utama
if (!isset($_SESSION['id_user']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'petugas')) {
    header("Location: index.php");
    exit;
}

try {
    // 1. TANGKAP SEMUA INPUT (Filter, Keyword, Pagination)
    // Ini berfungsi untuk menangkap pilihan filter status dari dropdown. Kalau kosong, defaultnya 'Semua'
    $filter_status = $_GET['status'] ?? 'Semua';
    // Ini berfungsi menangkap kata kunci pencarian yang diketik user
    $keyword = dapatkan_keyword();
    
    // Ini berfungsi mengatur pembagian halaman. Satu halaman isinya cuma 5 baris data laporan
    $batas = 5; 
    $halaman_aktif = isset($_GET['halaman']) ? (int)$_GET['halaman'] : 1;
    $awal_data = ($batas * $halaman_aktif) - $batas;

    // TAHAP 1: MENGHITUNG TOTAL DATA & PENDAPATAN (TANPA LIMIT PAGINATION)
    
    // Ini berfungsi untuk menghitung total semua transaksi dan menjumlahkan total pendapatan (cuma yang statusnya 'Lunas')
    $query_summary = "
        SELECT 
        COUNT(*) as total_transaksi, 
        SUM(CASE WHEN t.status_pembayaran = 'Lunas' THEN t.total_biaya ELSE 0 END) as total_uang
        FROM transaksi t
        JOIN anggota a ON t.id_anggota = a.id_anggota
        JOIN buku b ON t.id_buku = b.id_buku
        JOIN paket_sewa p ON t.id_paket = p.id_paket
        WHERE 1=1
    ";

    // Ini berfungsi untuk menyambung query di atas kalau user lagi nyari nama/judul tertentu
    if (!empty($keyword)) {
        $query_summary .= " AND (a.nama_lengkap LIKE :keyword_nama OR b.judul LIKE :keyword_judul)";
    }
    // Ini berfungsi untuk menyambung query kalau user milih filter status tertentu (selain 'Semua')
    if ($filter_status !== 'Semua') {
        $query_summary .= " AND t.status_akses = :status";
    }

    $stmt_summary = $pdo->prepare($query_summary);
    
    // Bind data untuk summary (menyuntikkan nilai variabel dengan aman ke database)
    if (!empty($keyword)) {
        $stmt_summary->bindValue(':keyword_nama', "%$keyword%", PDO::PARAM_STR);
        $stmt_summary->bindValue(':keyword_judul', "%$keyword%", PDO::PARAM_STR);
    }
    if ($filter_status !== 'Semua') {
        $stmt_summary->bindValue(':status', $filter_status, PDO::PARAM_STR);
    }
    
    $stmt_summary->execute();
    $summary = $stmt_summary->fetch(PDO::FETCH_ASSOC);
    
    // Ini berfungsi untuk menyimpan hasil perhitungan dari database ke dalam variabel PHP biar bisa dicetak ke HTML nanti
    $total_transaksi = $summary['total_transaksi'] ?? 0;
    $total_pendapatan = $summary['total_uang'] ?? 0;
    
    // Ini berfungsi menghitung jumlah halaman yang akan dibuat berdasarkan total datanya
    $total_halaman = ceil($total_transaksi / $batas);

    // TAHAP 2: MENGAMBIL DATA UNTUK DITAMPILKAN DI TABEL (DENGAN LIMIT)    
    // Ini berfungsi untuk menarik detail datanya. Pake LEFT JOIN buat ngambil nama admin yang nge-ACC transaksinya
    $query_tabel = "
        SELECT t.*, a.nama_lengkap, b.judul, p.nama_paket, o.nama_lengkap AS nama_admin 
        FROM transaksi t
        JOIN anggota a ON t.id_anggota = a.id_anggota
        JOIN buku b ON t.id_buku = b.id_buku
        JOIN paket_sewa p ON t.id_paket = p.id_paket
        LEFT JOIN operator o ON t.id_petugas = o.id 
        WHERE 1=1 
    ";

    // Sama kayak di atas, ini berfungsi nambahin syarat ke pencarian database kalau ada keyword
    if (!empty($keyword)) {
        $query_tabel .= " AND (a.nama_lengkap LIKE :keyword_nama OR b.judul LIKE :keyword_judul)";
    }
    // Ini juga berfungsi nambahin syarat ke database kalau ada filter status
    if ($filter_status !== 'Semua') {
        $query_tabel .= " AND t.status_akses = :status";
    }

    // Ini berfungsi buat mengurutkan data dari yang paling baru, terus dikasih batas (LIMIT) biar gak kepanjangan nampil di layarnya
    $query_tabel .= " ORDER BY t.id_transaksi DESC LIMIT :awal, :batas";

    $stmt_tabel = $pdo->prepare($query_tabel);

    // Bind data untuk tabel
    if (!empty($keyword)) {
        $stmt_tabel->bindValue(':keyword_nama', "%$keyword%", PDO::PARAM_STR);
        $stmt_tabel->bindValue(':keyword_judul', "%$keyword%", PDO::PARAM_STR);
    }
    if ($filter_status !== 'Semua') {
        $stmt_tabel->bindValue(':status', $filter_status, PDO::PARAM_STR);
    }
    
    // Bind Pagination (Menyuntikkan angka batas awal dan maksimal data)
    $stmt_tabel->bindValue(':awal', $awal_data, PDO::PARAM_INT);
    $stmt_tabel->bindValue(':batas', $batas, PDO::PARAM_INT);
    
    $stmt_tabel->execute();
    // Ini berfungsi menyimpan semua baris data dari database ke dalam array bernama $laporan
    $laporan = $stmt_tabel->fetchAll(PDO::FETCH_ASSOC);

} catch (PDOException $e) {
    // Berfungsi sebagai pengaman kalau database error, mematikan halaman dan nampilin pesan errornya
    die("Error Database: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Laporan Transaksi</title>
    <link rel="stylesheet" href="../libraries/css/all.min.css">
    <link rel="stylesheet" href="../assets/css/navbar.css">
    <link rel="stylesheet" href="../assets/css/sidebar.css">
    <link rel="stylesheet" href="../assets/css/kelola_buku.css">
    <link rel="stylesheet" href="../assets/css/laporan.css">
</head>
<body>
    <?php 
    // Berfungsi menyiapkan bagian atas web (Navbar), termasuk ngasih tau kalau fitur pencarian di sini ngarahnya ke halaman laporan.php ini juga
    $base_path = '../';
    $search_action = 'laporan.php';
    $search_placeholder = 'Cari nama anggota atau judul buku...';
    include '../includes/navbar.php'; 
    ?>
    
    <div class="main-wrapper">
        <?php include '../includes/sidebar.php'; // Berfungsi memanggil menu di pinggir kiri ?>

        <main class="content-area">
            <h2 style="color: #1A0A2E; margin-bottom: 20px;" class="hide-on-print">Laporan Riwayat Peminjaman</h2>
            
            <h2 style="display: none; text-align: center; margin-bottom: 20px;" onload="this.style.display='block'">Laporan Peminjaman Perpustakaan</h2>

            <div class="summary-container">
                <div class="summary-card">
                    <i class="fa-solid fa-file-invoice"></i>
                    <div class="summary-info">
                        <h4>Total Transaksi</h4>
                        <p><?php echo $total_transaksi; ?> Data</p>
                    </div>
                </div>
                <div class="summary-card" style="border-left-color: #10B981;">
                    <i class="fa-solid fa-rupiah-sign" style="color: #6EE7B7;"></i>
                    <div class="summary-info">
                        <h4>Total Pendapatan (Lunas)</h4>
                        <p>Rp <?php echo number_format($total_pendapatan, 0, ',', '.'); ?></p>
                    </div>
                </div>
            </div>

            <div class="filter-box">
                <form action="" method="GET" class="filter-form">
                    <label style="font-weight: bold; color: #5B3F7A;">Filter Status:</label>
                    <select name="status">
                        <option value="Semua" <?php echo ($filter_status == 'Semua') ? 'selected' : ''; ?>>Semua Transaksi</option>
                        <option value="Menunggu Konfirmasi" <?php echo ($filter_status == 'Menunggu Konfirmasi') ? 'selected' : ''; ?>>Menunggu Konfirmasi</option>
                        <option value="Aktif" <?php echo ($filter_status == 'Aktif') ? 'selected' : ''; ?>>Aktif (Sedang Dipinjam)</option>
                        <option value="Dibatalkan" <?php echo ($filter_status == 'Dibatalkan') ? 'selected' : ''; ?>>Dibatalkan / Ditolak</option>
                    </select>
                    <button type="submit" class="btn-filter">Terapkan</button>
                </form>

                <button onclick="window.print()" class="btn-print"><i class="fa-solid fa-print"></i> Cetak Laporan</button>
            </div>

            <?php tampilkan_alert_pencarian($keyword, 'laporan.php'); ?>
            <table class="tabel-data">
                <thead>
                    <tr>
                        <th>NO</th>
                        <th>TANGGAL</th>
                        <th>NAMA ANGGOTA</th>
                        <th>BUKU & PAKET</th>
                        <th>BIAYA</th>
                        <th>STATUS</th>
                        <th>DISETUJUI OLEH</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                    $no = 1; // Variabel bantuan buat bikin nomor urut
                    // Ini berfungsi untuk mengulang (melakukan loop) mencetak isi array laporan dari database ke baris-baris tabel
                    foreach ($laporan as $row): 
                    ?>
                    <tr>
                        <td><?php echo $no++; ?></td> <td><?php echo $row['tanggal_pinjam'] ? date('d/m/Y', strtotime($row['tanggal_pinjam'])) : '-'; ?></td>
                        
                        <td style="font-weight: bold;"><?php echo htmlspecialchars($row['nama_lengkap']); ?></td>
                        <td>
                            <div style="font-weight: bold;"><?php echo htmlspecialchars($row['judul']); ?></div>
                            <div style="font-size: 12px; color: #666;"><?php echo htmlspecialchars($row['nama_paket']); ?></div>
                        </td>
                        <td style="color: #059669; font-weight: bold;">Rp <?php echo number_format($row['total_biaya'], 0, ',', '.'); ?></td>
                        <td>
                            <?php 
                            // Ini berfungsi mengatur warna teks status. Kalau Aktif warnanya ijo, kalau selain itu (misal ditolak) warnanya merah
                            if ($row['status_akses'] == 'Aktif'): ?>
                                <span style="color: #065F46; font-weight: bold;">Lunas / Aktif</span>
                            <?php else: ?>
                                <span style="color: #991B1B; font-weight: bold;"><?php echo htmlspecialchars($row['status_akses']); ?></span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php 
                            // Ini berfungsi mengecek apa ada nama admin yang terekam nge-ACC transaksi ini
                            if (!empty($row['nama_admin'])): ?>
                                <?php echo htmlspecialchars($row['nama_admin']); ?>
                            <?php else: ?>
                                <span style="color: #999; font-style: italic;">Belum disetujui</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>

                    <?php 
                    // Ini berfungsi buat nampilin teks ini kalau ternyata query dari database itu gak nemu data sama sekali (kosong)
                    if(empty($laporan)): ?>
                    <tr>
                        <td colspan="7" style="text-align: center; color: #8A6BAE;">Tidak ada data laporan ditemukan.</td>
                    </tr>
                    <?php endif; ?>
                </tbody>
            </table>
            
            <?php 
            // Bagian ini berfungsi buat nampilin tombol angka halaman (Pagination) di bawah tabel
            if ($total_halaman > 0): ?>
                <div class="pagination-container" style="margin-top: 20px; display: flex; justify-content: center; gap: 8px;">
                    <?php for($i = 1; $i <= $total_halaman; $i++): ?>
                        <?php 
                            // Ini berfungsi ngebawa settingan filter & keyword di URL pas user pindah halaman, biar filter/pencariannya nggak keriset
                            $link_halaman = "?status=" . urlencode($filter_status) . "&halaman=$i";
                            if (!empty($keyword)) $link_halaman .= "&q=" . urlencode($keyword);
                            
                            // Ini berfungsi nentuin warna kotaknya. Kalau lagi di halaman aktif, warnanya jadi ungu solid
                            $is_active = ($i == $halaman_aktif);
                            $bg_color = $is_active ? '#7B2FBE' : '#fff';
                            $text_color = $is_active ? '#fff' : '#7B2FBE';
                        ?>
                        <a href="<?php echo $link_halaman; ?>" style="padding: 8px 14px; text-decoration: none; border: 1px solid #C084FC; border-radius: 5px; background-color: <?php echo $bg_color; ?>; color: <?php echo $text_color; ?>; font-weight: bold; transition: 0.3s;">
                            <?php echo $i; ?>
                        </a>
                    <?php endfor; ?>
                </div>
            <?php endif; ?>
        </main>
    </div>
</body>
</html>