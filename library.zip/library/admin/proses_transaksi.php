<?php
// Ini berfungsi untuk memanggil file keamanan (cek login) dan koneksi ke database
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Ini berfungsi sebagai penjaga pintu. Kalau yang akses bukan admin atau petugas (atau malah belum login), langsung ditendang balik ke halaman index
if (!isset($_SESSION['id_user']) || ($_SESSION['role'] !== 'admin' && $_SESSION['role'] !== 'petugas')) {
    header("Location: index.php");
    exit;
}

// Ini berfungsi untuk menangkap data dari URL (contoh di URL: ?id=5&aksi=acc). 
// $_GET['id'] nyimpen ID transaksinya, $_GET['aksi'] nyimpen perintahnya (mau di-acc atau ditolak)
$id_transaksi = $_GET['id'] ?? '';
$aksi = $_GET['aksi'] ?? '';

// Ini berfungsi untuk mencatat siapa petugas/admin yang lagi ngeproses transaksi ini dengan mengambil ID-nya dari sesi login
$id_petugas = $_SESSION['id_user']; 

// Ini berfungsi sebagai validasi keamanan tambahan. Kalau ID transaksi atau aksinya kosong (misal ada yang iseng ngetik URL sembarangan), langsung balikin ke halaman konfirmasi
if (empty($id_transaksi) || empty($aksi)) {
    header("Location: konfirmasi.php");
    exit;
}

try {
    // Skenario 1: Jika tombol "ACC" yang diklik
    if ($aksi === 'acc') {
        // 1. Ini berfungsi untuk ngecek buku ini dipinjam pakai paket yang durasinya berapa hari
        $query_paket = "
            SELECT p.durasi_paket 
            FROM transaksi t 
            JOIN paket_sewa p ON t.id_paket = p.id_paket 
            WHERE t.id_transaksi = ?
        ";
        $stmt_paket = $pdo->prepare($query_paket);
        $stmt_paket->execute([$id_transaksi]);
        $durasi = $stmt_paket->fetchColumn(); // Menyimpan angka durasinya

        if ($durasi) {
            // 2. LOGIKA MATEMATIKA TANGGAL
            // Ini berfungsi untuk mencatat tanggal hari ini secara otomatis
            $tgl_pinjam = date('Y-m-d'); 
            // Ini berfungsi untuk menghitung kapan buku harus dikembalikan (tanggal hari ini ditambah jumlah durasi hari paket)
            $tgl_kembali = date('Y-m-d', strtotime("+$durasi days")); 

            // 3. UPDATE DATABASE
            // Ini berfungsi untuk memperbarui baris data di tabel transaksi. 
            // Statusnya diubah jadi lunas/aktif, tanggalnya diisi hasil hitungan tadi, dan dicatat siapa petugas yang nge-ACC.
            $query_update = "
                UPDATE transaksi 
                SET status_pembayaran = 'Lunas', 
                    status_akses = 'Aktif', 
                    tanggal_pinjam = :tgl_pinjam, 
                    tenggat_kembali = :tgl_kembali,
                    id_petugas = :id_petugas
                WHERE id_transaksi = :id_transaksi
            ";
            
            $stmt_update = $pdo->prepare($query_update);
            $stmt_update->execute([
                'tgl_pinjam' => $tgl_pinjam,
                'tgl_kembali' => $tgl_kembali,
                'id_petugas' => $id_petugas,
                'id_transaksi' => $id_transaksi
            ]);
        }

    // Skenario 2: Jika tombol "Tolak" yang diklik
    } elseif ($aksi === 'tolak') {
        // Ini berfungsi untuk membatalkan transaksi. 
        // Status diubah jadi ditolak/dibatalkan. Tanggal pinjam/kembali dibiarkan kosong karena emang nggak jadi dipinjam.
        $query_update = "
            UPDATE transaksi 
            SET status_pembayaran = 'Ditolak', 
                status_akses = 'Dibatalkan',
                id_petugas = :id_petugas
            WHERE id_transaksi = :id_transaksi
        ";
        $stmt_update = $pdo->prepare($query_update);
        $stmt_update->execute([
            'id_petugas' => $id_petugas,
            'id_transaksi' => $id_transaksi
        ]);
    }

    // Ini berfungsi untuk melempar/mengarahkan admin kembali ke halaman tabel setelah proses ACC/Tolak selesai,
    // sambil membawa pesan di URL (?pesan=sukses) biar notifikasi hijaunya muncul.
    header("Location: konfirmasi.php?pesan=sukses");
    exit;

} catch (PDOException $e) {
    // Ini berfungsi sebagai pengaman kalau-kalau proses insert ke database gagal, kodenya berhenti dan nampilin pesan error
    die("Error memproses transaksi: " . $e->getMessage());
}
?>