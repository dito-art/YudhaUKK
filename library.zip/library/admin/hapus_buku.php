<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// 1. Keamanan Ekstra: Hanya Admin yang boleh menghapus buku
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// 2. Cek apakah ada ID yang dikirim melalui URL
if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id_buku = trim($_GET['id']);

    try {
        // Ambil nama file cover dan PDF dari database sebelum datanya dihapus
        // Sesuaikan 'file_buku' dengan nama kolom PDF di tabel buku milikmu
        $stmt = $pdo->prepare("SELECT cover, isi_buku FROM buku WHERE id_buku = :id");
        $stmt->execute(['id' => $id_buku]);
        $buku = $stmt->fetch(PDO::FETCH_ASSOC);

        // Jika data buku ditemukan di database
        if ($buku) {
            
            // Tentukan jalur (path) file fisik berada
            $path_cover = '../uploads/cover/' . $buku['cover'];
            $path_pdf = '../uploads/isi-buku/' . $buku['isi_buku']; 

            // LANGKAH A: HAPUS FILE FISIK DARI SERVER
            
            // Hapus Cover jika filenya ada
            if (!empty($buku['cover']) && file_exists($path_cover)) {
                unlink($path_cover);
            }

            // Hapus File PDF jika filenya ada
            if (!empty($buku['isi_buku']) && file_exists($path_pdf)) {
                unlink($path_pdf);
            }
            
            // Hapus catatannya dari tabel penghubung kategori_buku
            $query_hapus_relasi = "DELETE FROM kategori_buku WHERE id_buku = :id";
            $stmt_relasi = $pdo->prepare($query_hapus_relasi);
            $stmt_relasi->execute(['id' => $id_buku]);
            
            // Setelah relasi aman, baru hapus buku dari tabel induk
            $query_delete = "DELETE FROM buku WHERE id_buku = :id";
            $stmt_delete = $pdo->prepare($query_delete);
            $stmt_delete->execute(['id' => $id_buku]);

            // Redirect kembali ke kelola buku dengan pesan sukses di URL
            header("Location: kelola_buku.php?pesan=hapus_sukses");
            exit;

        } else {
            die("Data buku tidak ditemukan.");
        }

    } catch(PDOException $e) {
        die("Error sistem: " . $e->getMessage());
    }
} else {
    // Jika tidak ada parameter ID di URL
    header("Location: kelola_buku.php");
    exit;
}
?>