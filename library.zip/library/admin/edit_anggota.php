<?php
require_once '../auth/auth_guard.php';
require_once '../config/koneksi.php';

// Satpam: Hanya Admin yang boleh masuk
if (!isset($_SESSION['id_user']) || $_SESSION['role'] !== 'admin') {
    header("Location: index.php");
    exit;
}

$id_anggota = $_GET['id'] ?? '';
$pesan = '';

// 1. Ambil data lama anggota untuk ditampilkan di form
try {
    $stmt = $pdo->prepare("SELECT * FROM anggota WHERE id_anggota = ?");
    $stmt->execute([$id_anggota]);
    $anggota = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$anggota) {
        die("Data anggota tidak ditemukan.");
    }
} catch (PDOException $e) {
    die("Error: " . $e->getMessage());
}

// 2. Proses jika tombol simpan ditekan
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nama_lengkap = trim($_POST['nama_lengkap']);
    $username = trim($_POST['username']);
    $nis = trim($_POST['nis']);
    $kelas = $_POST['kelas'];
    $jurusan = $_POST['jurusan'];
    $no_telp = trim($_POST['no_telp']);
    $reset_password = isset($_POST['reset_password']);

    try {
        // Mulai membangun query update
        $sql = "UPDATE anggota SET 
                nama_lengkap = :nama, 
                username = :user, 
                nis = :nis, 
                kelas = :kelas, 
                jurusan = :jurusan, 
                no_telp = :telp";
        
        $params = [
            'nama' => $nama_lengkap,
            'user' => $username,
            'nis' => $nis,
            'kelas' => $kelas,
            'jurusan' => $jurusan,
            'telp' => $no_telp,
            'id' => $id_anggota
        ];

        // Jika checkbox reset password dicentang
        if ($reset_password) {
            $password_default = password_hash('123456', PASSWORD_DEFAULT);
            $sql .= ", password = :pass";
            $params['pass'] = $password_default;
        }

        $sql .= " WHERE id_anggota = :id";
        
        $stmt_update = $pdo->prepare($sql);
        $stmt_update->execute($params);

        header("Location: kelola_anggota.php?pesan=edit_sukses");
        exit;

    } catch (PDOException $e) {
        $pesan = "<div class='alert alert-error'>Gagal memperbarui data: " . $e->getMessage() . "</div>";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Edit Anggota</title>
    <link rel="stylesheet" href="../assets/css/tambah_buku.css">
    <style>
        .form-group select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; }
        .checkbox-group { background: #F3E8FF; padding: 10px; border-radius: 4px; border: 1px dashed #7B2FBE; margin-top: 20px; margin-bottom: 20px;}
    </style>
</head>
<body>

    <div class="form-container">
        <h2 style="color: #1A0A2E; margin-top: 10px; margin-bottom: 20px;">Edit Data Anggota</h2>
        
        <?php echo $pesan; ?>

        <form action="" method="POST">
            <div class="form-group">
                <label>Nama Lengkap</label>
                <input type="text" name="nama_lengkap" value="<?php echo htmlspecialchars($anggota['nama_lengkap']); ?>" required>
            </div>
            
            <div class="form-group">
                <label>Username</label>
                <input type="text" name="username" value="<?php echo htmlspecialchars($anggota['username']); ?>" required>
            </div>

            <div class="form-group">
                <label>NIS</label>
                <input type="text" name="nis" value="<?php echo htmlspecialchars($anggota['nis']); ?>" required>
            </div>

            <div style="display: flex; gap: 15px;">
                <div class="form-group" style="flex: 1;">
                    <label>Kelas</label>
                    <select name="kelas" required>
                        <option value="10" <?php echo ($anggota['kelas'] == 'X') ? 'selected' : ''; ?>>X</option>
                        <option value="11" <?php echo ($anggota['kelas'] == 'XI') ? 'selected' : ''; ?>>XI</option>
                        <option value="12" <?php echo ($anggota['kelas'] == 'XII') ? 'selected' : ''; ?>>XII</option>
                    </select>
                </div>
                <div class="form-group" style="flex: 1;">
                    <label>Jurusan</label>
                    <input type="text" name="jurusan" value="<?php echo htmlspecialchars($anggota['jurusan']); ?>" placeholder="Contoh: RPL" required>
                </div>
            </div>

            <div class="form-group">
                <label>No. Telepon</label>
                <input type="text" name="no_telp" value="<?php echo htmlspecialchars($anggota['no_telp']); ?>" required>
            </div>

            <div class="checkbox-group">
                <label style="display: flex; align-items: center; gap: 10px; cursor: pointer; color: #7B2FBE;">
                    <input type="checkbox" name="reset_password" style="width: auto;">
                    <span>Reset password ke default (<strong>123456</strong>)</span>
                </label>
                <small style="color: #6b7280; display: block; margin-top: 5px;">*Centang ini jika anggota lupa password akunnya.</small>
            </div>

            <button type="submit" class="btn-submit">Simpan Perubahan</button>
            <a href="kelola_anggota.php" style="margin-left: 10px; color: #8A6BAE; text-decoration: none;">Batal</a>
        </form>
    </div>

</body>
</html>