<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>LiteraDigital — Perpustakaan Sekolah Digital</title>
  <link rel="stylesheet" href="fontawesome/css/all.min.css" />
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,500;0,700;1,500&family=DM+Sans:wght@300;400;500&display=swap" rel="stylesheet">

  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

    :root {
      --cream:   #F5F0E8;
      --paper:   #EDE8DC;
      --ink:     #1C1A17;
      --brown:   #6B4C2A;
      --amber:   #D4862A;
      --amber-lt:#F0B060;
      --sage:    #4A6741;
      --sage-lt: #A8C4A0;
      --dust:    #B8A898;
    }

    html { scroll-behavior: smooth; }

    body {
      font-family: 'DM Sans', sans-serif;
      background: var(--cream);
      color: var(--ink);
      overflow-x: hidden;
    }

    /* ── NOISE TEXTURE OVERLAY ── */
    body::before {
      content: '';
      position: fixed; inset: 0;
      background-image: url("data:image/svg+xml,%3Csvg viewBox='0 0 200 200' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='n'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.75' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23n)' opacity='0.04'/%3E%3C/svg%3E");
      pointer-events: none;
      z-index: 0;
      opacity: .6;
    }

    /* ══════════════════════════
         NAVBAR
    ══════════════════════════ */
    nav {
      position: sticky; top: 0; z-index: 100;
      display: flex; align-items: center; gap: 1.5rem;
      padding: .85rem 4vw;
      background: rgba(245,240,232,.88);
      backdrop-filter: blur(14px);
      border-bottom: 1px solid var(--paper);
      box-shadow: 0 2px 24px rgba(28,26,23,.07);
    }

    /* Logo */
    .nav-logo {
      display: flex; align-items: center; gap: .55rem;
      text-decoration: none; flex-shrink: 0;
    }
    .nav-logo .logo-icon {
      width: 38px; height: 38px;
      background: var(--brown);
      border-radius: 10px;
      display: grid; place-items: center;
      color: var(--cream);
      font-size: 1rem;
      box-shadow: inset 0 -2px 0 rgba(0,0,0,.25);
    }
    .nav-logo .logo-text {
      font-family: 'Playfair Display', serif;
      font-size: 1.25rem;
      font-weight: 700;
      color: var(--ink);
      letter-spacing: -.02em;
      line-height: 1.1;
    }
    .nav-logo .logo-text span { color: var(--amber); }
    .nav-logo .logo-sub {
      font-size: .6rem;
      font-weight: 300;
      color: var(--dust);
      letter-spacing: .06em;
      text-transform: uppercase;
      display: block;
    }

    /* Search */
    .nav-search {
      flex: 1;
      max-width: 420px;
      position: relative;
      margin-left: auto;
    }
    .nav-search input {
      width: 100%;
      padding: .6rem 1rem .6rem 2.6rem;
      background: var(--paper);
      border: 1.5px solid transparent;
      border-radius: 50px;
      font-family: 'DM Sans', sans-serif;
      font-size: .88rem;
      color: var(--ink);
      outline: none;
      transition: border .2s, box-shadow .2s;
    }
    .nav-search input::placeholder { color: var(--dust); }
    .nav-search input:focus {
      border-color: var(--amber);
      box-shadow: 0 0 0 3px rgba(212,134,42,.12);
    }
    .nav-search .search-icon {
      position: absolute; left: .85rem; top: 50%; transform: translateY(-50%);
      color: var(--dust); font-size: .85rem; pointer-events: none;
    }
    .nav-search .search-btn {
      position: absolute; right: .4rem; top: 50%; transform: translateY(-50%);
      background: var(--amber);
      border: none; border-radius: 50px;
      padding: .3rem .85rem;
      color: #fff; font-size: .75rem; font-weight: 500;
      cursor: pointer; transition: background .2s;
    }
    .nav-search .search-btn:hover { background: var(--brown); }

    /* Nav links */
    .nav-links { display: flex; align-items: center; gap: .25rem; }
    .nav-links a {
      display: flex; align-items: center; gap: .4rem;
      padding: .45rem .9rem;
      border-radius: 8px;
      text-decoration: none;
      font-size: .88rem; font-weight: 500;
      color: var(--ink);
      transition: background .18s, color .18s;
    }
    .nav-links a:hover { background: var(--paper); color: var(--brown); }
    .nav-links a i { font-size: .8rem; color: var(--amber); }

    /* Auth buttons */
    .nav-auth { display: flex; align-items: center; gap: .5rem; flex-shrink: 0; }
    .btn-login {
      padding: .45rem 1.1rem;
      border: 1.5px solid var(--brown);
      border-radius: 8px;
      background: transparent;
      color: var(--brown);
      font-family: 'DM Sans', sans-serif;
      font-size: .88rem; font-weight: 500;
      cursor: pointer; text-decoration: none;
      transition: background .2s, color .2s;
    }
    .btn-login:hover { background: var(--brown); color: var(--cream); }
    .btn-register {
      padding: .45rem 1.1rem;
      border: 1.5px solid var(--amber);
      border-radius: 8px;
      background: var(--amber);
      color: #fff;
      font-family: 'DM Sans', sans-serif;
      font-size: .88rem; font-weight: 500;
      cursor: pointer; text-decoration: none;
      transition: background .2s;
    }
    .btn-register:hover { background: var(--brown); border-color: var(--brown); }

    /* ══════════════════════════
         HERO
    ══════════════════════════ */
    .hero {
      position: relative;
      min-height: calc(100vh - 66px);
      display: flex; align-items: center;
      padding: 5rem 4vw 4rem;
      overflow: hidden;
    }

    /* decorative background shapes */
    .hero::before {
      content: '';
      position: absolute; top: -120px; right: -80px;
      width: 640px; height: 640px;
      background: radial-gradient(circle at 60% 40%, rgba(212,134,42,.18) 0%, transparent 65%);
      border-radius: 50%;
      animation: pulse 8s ease-in-out infinite alternate;
    }
    .hero::after {
      content: '';
      position: absolute; bottom: -100px; left: -60px;
      width: 500px; height: 500px;
      background: radial-gradient(circle at 40% 60%, rgba(74,103,65,.12) 0%, transparent 65%);
      border-radius: 50%;
      animation: pulse 10s ease-in-out 2s infinite alternate;
    }
    @keyframes pulse {
      from { transform: scale(1); }
      to   { transform: scale(1.12); }
    }

    .hero-inner {
      position: relative; z-index: 1;
      max-width: 1200px; margin: 0 auto; width: 100%;
      display: grid; grid-template-columns: 1fr 1fr; gap: 4rem; align-items: center;
    }

    /* Left: text */
    .hero-text { animation: fadeUp .9s ease both; }
    @keyframes fadeUp {
      from { opacity: 0; transform: translateY(32px); }
      to   { opacity: 1; transform: translateY(0); }
    }

    .hero-badge {
      display: inline-flex; align-items: center; gap: .5rem;
      padding: .35rem .9rem;
      background: var(--sage-lt);
      color: var(--sage);
      border-radius: 50px;
      font-size: .78rem; font-weight: 500;
      letter-spacing: .04em;
      margin-bottom: 1.5rem;
    }
    .hero-badge i { font-size: .7rem; }

    .hero-headline {
      font-family: 'Playfair Display', serif;
      font-size: clamp(2.4rem, 5vw, 3.8rem);
      font-weight: 700;
      line-height: 1.12;
      letter-spacing: -.03em;
      color: var(--ink);
      margin-bottom: 1.25rem;
    }
    .hero-headline em {
      font-style: italic;
      color: var(--amber);
      position: relative;
    }
    .hero-headline em::after {
      content: '';
      position: absolute; left: 0; bottom: -2px;
      width: 100%; height: 3px;
      background: var(--amber-lt);
      border-radius: 2px;
    }

    .hero-sub {
      font-size: 1.05rem;
      line-height: 1.7;
      color: #5A5448;
      max-width: 460px;
      margin-bottom: 2.25rem;
    }

    .hero-cta {
      display: flex; align-items: center; flex-wrap: wrap; gap: .85rem;
    }
    .cta-primary {
      display: inline-flex; align-items: center; gap: .6rem;
      padding: .85rem 1.8rem;
      background: var(--ink);
      color: var(--cream);
      border-radius: 12px;
      font-size: .95rem; font-weight: 500;
      text-decoration: none;
      transition: background .2s, transform .2s, box-shadow .2s;
      box-shadow: 0 4px 20px rgba(28,26,23,.18);
    }
    .cta-primary:hover {
      background: var(--brown);
      transform: translateY(-2px);
      box-shadow: 0 8px 28px rgba(107,76,42,.3);
    }
    .cta-secondary {
      display: inline-flex; align-items: center; gap: .6rem;
      padding: .85rem 1.5rem;
      border: 1.5px solid var(--dust);
      border-radius: 12px;
      font-size: .95rem; font-weight: 500;
      color: var(--brown);
      text-decoration: none;
      transition: border-color .2s, background .2s;
    }
    .cta-secondary:hover { border-color: var(--brown); background: var(--paper); }

    .hero-stats {
      display: flex; gap: 2rem; margin-top: 3rem;
    }
    .stat { border-left: 2.5px solid var(--amber); padding-left: .85rem; }
    .stat-num {
      font-family: 'Playfair Display', serif;
      font-size: 1.6rem; font-weight: 700; color: var(--ink);
      line-height: 1;
    }
    .stat-label { font-size: .78rem; color: var(--dust); margin-top: .2rem; }

    /* Right: book illustration */
    .hero-visual {
      display: flex; justify-content: center; align-items: center;
      animation: fadeUp .9s .2s ease both;
    }
    .book-stack {
      position: relative;
      width: 320px; height: 380px;
    }
    .book {
      position: absolute;
      border-radius: 8px 14px 14px 8px;
      box-shadow: 4px 4px 18px rgba(28,26,23,.18);
      transition: transform .35s;
    }
    .book:hover { transform: translateY(-8px) rotate(0deg) !important; }

    .book-1 {
      width: 200px; height: 270px;
      background: linear-gradient(135deg, #5C3D1E, #8B6240);
      bottom: 20px; left: 30px;
      transform: rotate(-4deg);
      display: flex; flex-direction: column; justify-content: flex-end; padding: 1.2rem 1rem;
    }
    .book-2 {
      width: 180px; height: 240px;
      background: linear-gradient(135deg, #2F4D2A, #4A6741);
      bottom: 40px; left: 100px;
      transform: rotate(3deg);
    }
    .book-3 {
      width: 160px; height: 210px;
      background: linear-gradient(135deg, #C47820, #E8A83A);
      bottom: 60px; left: 170px;
      transform: rotate(-2deg);
      display: flex; flex-direction: column; padding: 1rem .85rem;
    }

    .book-spine {
      position: absolute; left: 0; top: 0; bottom: 0;
      width: 18px;
      border-radius: 8px 0 0 8px;
      background: rgba(0,0,0,.2);
    }

    .book-title-fake {
      color: rgba(255,255,255,.85);
      font-family: 'Playfair Display', serif;
      font-size: .72rem;
      line-height: 1.35;
      margin-left: 24px;
    }
    .book-lines {
      display: flex; flex-direction: column; gap: 5px;
      margin: auto 0 0 24px;
    }
    .book-line {
      height: 3px; border-radius: 2px;
      background: rgba(255,255,255,.25);
    }
    .book-line:nth-child(1) { width: 90%; }
    .book-line:nth-child(2) { width: 70%; }
    .book-line:nth-child(3) { width: 80%; }

    /* floating card */
    .float-card {
      position: absolute; top: 20px; right: -10px;
      background: rgba(245,240,232,.95);
      backdrop-filter: blur(8px);
      border: 1px solid var(--paper);
      border-radius: 14px;
      padding: .8rem 1rem;
      box-shadow: 0 8px 30px rgba(28,26,23,.12);
      display: flex; align-items: center; gap: .65rem;
      font-size: .8rem;
      animation: floatCard 4s ease-in-out infinite alternate;
      width: 180px;
    }
    @keyframes floatCard {
      from { transform: translateY(0); }
      to   { transform: translateY(-10px); }
    }
    .float-card .fc-icon {
      width: 36px; height: 36px; flex-shrink: 0;
      background: var(--amber);
      border-radius: 10px;
      display: grid; place-items: center;
      color: #fff; font-size: .95rem;
    }
    .float-card .fc-label { font-weight: 300; color: var(--dust); font-size: .72rem; }
    .float-card .fc-value { font-weight: 600; color: var(--ink); }

    .float-card-2 {
      position: absolute; bottom: 30px; right: -20px;
      background: var(--sage);
      border-radius: 14px;
      padding: .7rem 1rem;
      box-shadow: 0 8px 30px rgba(74,103,65,.3);
      display: flex; align-items: center; gap: .55rem;
      color: #fff;
      font-size: .8rem;
      animation: floatCard 5s ease-in-out 1s infinite alternate;
    }
    .float-card-2 i { font-size: 1rem; }
    .float-card-2 strong { font-weight: 600; }

    /* ══════════════════════════
         RESPONSIVE
    ══════════════════════════ */
    @media (max-width: 900px) {
      .hero-inner { grid-template-columns: 1fr; gap: 2.5rem; text-align: center; }
      .hero-sub { margin-left: auto; margin-right: auto; }
      .hero-cta { justify-content: center; }
      .hero-stats { justify-content: center; }
      .hero-visual { display: none; }
      .nav-search { max-width: 260px; }
    }

    @media (max-width: 600px) {
      nav { flex-wrap: wrap; gap: .75rem; }
      .nav-search { order: 3; max-width: 100%; flex: 1 1 100%; }
      .nav-links a span { display: none; }
      .logo-text .logo-sub { display: none; }
    }
  </style>
</head>
<body>

  <!-- ═══════ NAVBAR ═══════ -->
  <nav>
    <a href="/" class="nav-logo">
      <div class="logo-icon"><i class="fa-solid fa-book-open"></i></div>
      <div class="logo-text">
        Litera<span>Digital</span>
        <span class="logo-sub">Perpustakaan Sekolah</span>
      </div>
    </a>

    <div class="nav-search">
      <i class="fa-solid fa-magnifying-glass search-icon"></i>
      <input type="text" placeholder="Cari judul, penulis, atau ISBN…" />
      <button class="search-btn">Cari</button>
    </div>

    <div class="nav-links">
      <a href="/katalog">
        <i class="fa-solid fa-layer-group"></i>
        <span>Katalog Buku</span>
      </a>
    </div>

    <div class="nav-auth">
      <a href="/login" class="btn-login"><i class="fa-regular fa-user"></i> Login</a>
      <a href="/daftar" class="btn-register"><i class="fa-solid fa-pen-nib"></i> Daftar</a>
    </div>
  </nav>

  <!-- ═══════ HERO ═══════ -->
  <section class="hero">
    <div class="hero-inner">

      <!-- Text -->
      <div class="hero-text">
        <div class="hero-badge">
          <i class="fa-solid fa-circle-check"></i>
          Akses Gratis untuk Seluruh Siswa
        </div>

        <h1 class="hero-headline">
          Temukan <em>Ribuan Buku</em><br>
          di Ujung Jarimu
        </h1>

        <p class="hero-sub">
          Perpustakaan digital sekolah kami menghadirkan koleksi buku pelajaran, fiksi, 
          sains, dan referensi ilmiah — tersedia kapan saja, di mana saja, tanpa batas waktu.
        </p>

        <div class="hero-cta">
          <a href="/katalog" class="cta-primary">
            <i class="fa-solid fa-books"></i> Jelajahi Katalog
          </a>
          <a href="/tentang" class="cta-secondary">
            <i class="fa-regular fa-circle-play"></i> Cara Kerja
          </a>
        </div>

        <div class="hero-stats">
          <div class="stat">
            <div class="stat-num">12.000+</div>
            <div class="stat-label">Koleksi Buku</div>
          </div>
          <div class="stat">
            <div class="stat-num">48</div>
            <div class="stat-label">Kategori</div>
          </div>
          <div class="stat">
            <div class="stat-num">3.800+</div>
            <div class="stat-label">Siswa Aktif</div>
          </div>
        </div>
      </div>

      <!-- Visual -->
      <div class="hero-visual">
        <div class="book-stack">

          <!-- Book 1 – dark brown -->
          <div class="book book-1">
            <div class="book-spine"></div>
            <div class="book-lines">
              <div class="book-line"></div>
              <div class="book-line"></div>
              <div class="book-line"></div>
            </div>
            <div class="book-title-fake">Sejarah<br>Nusantara</div>
          </div>

          <!-- Book 2 – green -->
          <div class="book book-2">
            <div class="book-spine"></div>
          </div>

          <!-- Book 3 – amber -->
          <div class="book book-3">
            <div class="book-spine"></div>
            <div class="book-title-fake">Fisika<br>Modern</div>
          </div>

          <!-- Floating card 1 -->
          <div class="float-card">
            <div class="fc-icon"><i class="fa-solid fa-star"></i></div>
            <div>
              <div class="fc-label">Buku Terpopuler</div>
              <div class="fc-value">Laskar Pelangi</div>
            </div>
          </div>

          <!-- Floating card 2 -->
          <div class="float-card-2">
            <i class="fa-solid fa-bolt"></i>
            <div><strong>Baru ditambah</strong> hari ini</div>
          </div>

        </div>
      </div>

    </div>
  </section>

</body>
</html>