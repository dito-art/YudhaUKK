<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Herta's Library</title>
    <link rel="stylesheet" href="libraries/css/all.min.css">
    <link rel="stylesheet" href="assets/css/index.css">
    <link rel="stylesheet" href="assets/css/navbar.css">
</head>
<body>

    <?php 
    $search_action = 'katalog.php'; 
    $search_placeholder = 'Cari judul buku atau penulis...';
    include 'includes/navbar.php'; ?>
    <header class="hero">
    <div class="hero-content">
        <h1>Jelajahi Dunia Lewat <span>Genggamanmu</span></h1>
        <p>Pinjam dan baca banyak koleksi buku digital sekolah kapan saja dan di mana saja. Lebih mudah, lebih cepat, tanpa ribet.</p>
        <div class="hero-buttons">
            <a href="katalog.php" class="btn-hero-primary">Temukan Bukumu</a>
            <a href="auth/register.php" class="btn-hero-secondary">Daftar Sekarang</a>
        </div>
    </div>
</header>
    </body>
</html>