<?php
session_start();
require_once 'includes/functions.php';
require_once 'config/koneksi.php';

try {
    $keyword = dapatkan_keyword();

    if (!empty($keyword)) {
        $query = "SELECT * FROM buku WHERE judul LIKE :keyword_judul OR penulis LIKE :keyword_penulis ORDER BY id_buku DESC";
        $stmt = $pdo->prepare($query);
        $stmt->execute([
            'keyword_judul' => "%$keyword%",
            'keyword_penulis' => "%$keyword%"
            ]);
    } else {
        $query = "SELECT * FROM buku ORDER BY id_buku DESC";
        $stmt = $pdo->query($query);
    }
    
    $daftar_buku = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch(PDOException $e) {
    die("Error: " . $e->getMessage());
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Katalog Buku</title>
    <link rel="stylesheet" href="libraries/css/all.min.css">
    <link rel="stylesheet" href="assets/css/navbar.css">
    <link rel="stylesheet" href="assets/css/katalog.css">
</head>
<body>

    <?php
        $search_action = 'katalog.php';
        $search_placeholder = 'Cari judul atau penulis...';
        $show_dashboard_btn = true;
        include 'includes/navbar.php'; 
     ?>

    <div class="container">
        <div class="katalog-header">
            <h2>Katalog Buku Digital</h2>
            <p style="color: #7f8c8d;">Temukan, pinjam, dan baca buku favoritmu.</p>
        </div>

        <?php tampilkan_alert_pencarian($keyword, 'katalog.php'); ?>

        <div class="grid-buku">
            <?php foreach ($daftar_buku as $buku): ?>
                <div class="card-buku">
                    <img src="uploads/cover/<?php echo htmlspecialchars($buku['cover']); ?>" alt="Cover Buku" class="cover-buku">
                    
                    <div class="judul-buku"><?php echo htmlspecialchars($buku['judul']); ?></div>
                    <div class="penulis-buku">Oleh: <?php echo htmlspecialchars($buku['penulis']); ?></div>
                    
                    <?php if (!isset($_SESSION['id_user'])): ?>
                        <a href="auth/login.php" class="btn-action btn-guest"><i class="fa-solid fa-lock"></i> Login untuk Pinjam</a>
                    <?php elseif ($_SESSION['role'] === 'anggota'): ?>
                        <a href="detail_buku.php?id=<?php echo $buku['id_buku']; ?>" class="btn-action btn-member"><i class="fa-solid fa-book-open"></i> Lihat Detail</a>
                    <?php else: ?>
                        <a href="detail_buku.php?id=<?php echo $buku['id_buku']; ?>" class="btn-action btn-admin"><i class="fa-solid fa-pen-to-square"></i> Lihat Detail</a>
                    <?php endif; ?>
                </div>
            <?php endforeach; ?>
        </div>
    </div>

</body>
</html>