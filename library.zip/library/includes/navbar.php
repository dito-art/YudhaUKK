<?php
$sudahLogin = isset($_SESSION['nama_lengkap']);
$role = $_SESSION['role'] ?? ''; 

$action_url = $search_action ?? 'katalog.php';
$teks_placeholder = $search_placeholder ?? 'Cari judul atau penulis...';

$path = $base_path ?? '';
$tampilkan_tombol_dashboard = $show_dashboard_btn ?? false;

// Tentukan tujuan link logo berdasarkan role
$link_logo = 'index.php'; // Default untuk Guest (kembali ke landing page)
$teks_kembali = 'Ke Beranda';
$icon_kembali = 'fa-house';

if ($role === 'admin' || $role === 'petugas') {
    $link_logo = 'admin/index.php';
    $teks_kembali = 'Ke Dashboard';
    $icon_kembali = 'fa-house';
} elseif ($role === 'anggota') {
    $link_logo = 'anggota/index.php'; 
    $teks_kembali = 'Ke Dashboard';
    $icon_kembali = 'fa-house';
}
?>

<nav class="navbar">
    <a href="<?php echo htmlspecialchars($path . $link_logo); ?>" class="logo">
        <img src="<?php echo htmlspecialchars($path); ?>assets/img/madamherta.png" alt="Icon">Herta's Library
    </a>

    <form action="<?php echo htmlspecialchars($action_url); ?>" method="GET" class="search-form">
        <input type="text" name="q" placeholder="<?php echo htmlspecialchars($teks_placeholder); ?>">
        <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>

    <?php if ($sudahLogin): ?>
        <div class="nav-links" style="display: flex; align-items: center; gap: 20px;">
            
            <?php if ($tampilkan_tombol_dashboard): ?>
                <a href="<?php echo htmlspecialchars($path . $link_logo); ?>" class="btn-dashboard" style="text-decoration: none; font-weight: bold; color: #5B3F7A;">
                    <i class="fa-solid <?php echo $icon_kembali; ?>"></i> <?php echo $teks_kembali; ?>
                </a>
            <?php endif; ?>

            <div class="user-profile" style="display: flex; align-items: center; gap: 5px;">
                <i class="fa-solid fa-circle-user"></i>
                <span><?php echo htmlspecialchars($_SESSION['nama_lengkap']); ?></span>
            </div>
        </div>

    <?php else: ?>
        <div class="nav-links" style="display: flex; align-items: center; gap: 20px;">
            
            <?php if ($tampilkan_tombol_dashboard): ?>
                <a href="<?php echo htmlspecialchars($path . $link_logo); ?>" class="btn-dashboard" style="text-decoration: none; font-weight: bold; color: #5B3F7A;">
                    <i class="fa-solid <?php echo $icon_kembali; ?>"></i> <?php echo $teks_kembali; ?>
                </a>
            <?php else: ?>
                <a href="<?php echo htmlspecialchars($path); ?>katalog.php" style="text-decoration: none; color: inherit;">Katalog Buku</a>
            <?php endif; ?>

            <div class="auth-button">
                <a href="<?php echo htmlspecialchars($path); ?>auth/login.php" class="btn-login">Login</a>
                <a href="<?php echo htmlspecialchars($path); ?>auth/register.php" class="btn-register">Daftar</a>
            </div>
        </div>

    <?php endif; ?>
</nav>