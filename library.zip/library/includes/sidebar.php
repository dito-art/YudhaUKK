<?php
$role = $_SESSION['role'];
$isAdmin = in_array($role, ['admin', 'petugas']);
?>

<aside class="sidebar">
    <div class="menu-items">

        <?php if ($isAdmin): ?>
            <a href="index.php" class="menu-link"><i class="fa-solid fa-house"></i> Dashboard</a>
            <a href="../katalog.php" class="menu-link"><i class="fa-solid fa-book-bookmark"></i></i> Katalog Buku</a>

            <?php if ($role === 'admin'): ?>
                <div class="menu-section-label">Menu Master</div>
                <a href="kelola_buku.php" class="menu-link"><i class="fa-solid fa-book"></i> Kelola Buku</a>
                <a href="kelola_kategori.php" class="menu-link"><i class="fa-solid fa-tags"></i> Kelola Kategori</a>

                <div class="menu-section-label">Manajemen User</div>
                <a href="kelola_anggota.php" class="menu-link"><i class="fa-solid fa-users"></i> Kelola Anggota</a>
                <a href="kelola_operator.php" class="menu-link"><i class="fa-solid fa-user-shield"></i> Kelola Admin/Petugas</a>
            <?php endif; ?>
            <div class="menu-section-label">Transaksi</div>
            <a href="konfirmasi.php" class="menu-link"><i class="fa-solid fa-check-to-slot"></i> Konfirmasi Pinjaman</a>
            <a href="laporan.php" class="menu-link"><i class="fa-solid fa-file-lines"></i> Laporan Riwayat</a>

        <?php else: ?>
            <!-- ===== SIDEBAR ANGGOTA ===== -->
            <a href="index.php" class="menu-link"><i class="fa-solid fa-house"></i> Dashboard</a>
            <a href="../katalog.php" class="menu-link"><i class="fa-solid fa-book"></i> Katalog Buku</a>
            <a href="profil.php" class="menu-link"><i class="fa-solid fa-gear"></i> Profil</a>

        <?php endif; ?>

    </div>

    <a href="../auth/logout.php" class="menu-link btn-logout">
        <i class="fa-solid fa-right-from-bracket"></i> Logout
    </a>
</aside>

<script>
// Memaksa halaman memuat ulang jika dibuka dari cache (tombol back)
window.addEventListener("pageshow", function (event) {
    // Jika halaman dimuat dari cache (persisted) atau navigasi tipe 2 (back/forward)
    if (event.persisted || (window.performance && window.performance.navigation.type === 2)) {
        // Paksa reload dari server, bukan dari cache
        window.location.reload(); 
    }
});
</script>