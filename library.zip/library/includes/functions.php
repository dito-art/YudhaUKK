<?php

/**
 * Fungsi untuk menangkap kata kunci pencarian dari URL
 */
function dapatkan_keyword() {
    return isset($_GET['q']) ? trim($_GET['q']) : '';
}

/**
 * Fungsi untuk menampilkan alert dan tombol reset pencarian
 * $keyword: Kata kunci yang sedang dicari
 * $url_reset: Link untuk kembali (contoh: 'kelola_kategori.php')
 */
function tampilkan_alert_pencarian($keyword, $url_reset) {
    if (!empty($keyword)) {
        // Kita simpan HTML-nya di dalam variabel agar rapi, lalu kita echo
        $html = '
        <div style="margin-bottom: 15px; display: flex; justify-content: space-between; align-items: center; background: #EDE9FE; padding: 12px 15px; border-radius: 8px; border-left: 4px solid #5B3F7A;">
            <span style="color: #1A0A2E;">Menampilkan hasil pencarian untuk: <strong>"' . htmlspecialchars($keyword) . '"</strong></span>
            <a href="' . htmlspecialchars($url_reset) . '" style="background: #e74c3c; color: white; padding: 6px 12px; border-radius: 5px; text-decoration: none; font-size: 14px; font-weight: bold;">
                <i class="fa-solid fa-xmark"></i> Reset Pencarian
            </a>
        </div>';
        
        echo $html;
    }
}
?>